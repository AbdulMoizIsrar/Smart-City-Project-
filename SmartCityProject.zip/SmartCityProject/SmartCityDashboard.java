import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class SmartCityDashboard extends JFrame {
    // Transport module variables
    private CardLayout layout;
    private JPanel rootPanel;
    private double farePerKM = 5.0;
    private final String ROUTE_FILE = "routes.dat";
    private final String FARE_FILE = "fare.dat";
    private Map<String, Map<String, Double>> routes = new LinkedHashMap<>();
    
    // Emergency Services variables
    private AmbulanceService ambulanceService;
    private Dispatcher dispatcher;
    private JTextArea emergencyOutputArea;
    
    // Power Station variables
    private static final DataStore STORE = new FileDataStore();
    private static AbstractUser currentUser;

    public SmartCityDashboard() {
        setTitle("SMART CITY MANAGEMENT SYSTEM");
        setSize(1200, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize emergency services
        ambulanceService = new AmbulanceService();
        dispatcher = new Dispatcher("Dispatcher1", ambulanceService);
        if (ambulanceService.getAllAmbulances().isEmpty()) {
            setupInitialEmergencyData();
        }

        // Initialize power station data
        initSampleData();

        layout = new CardLayout();
        rootPanel = new JPanel(layout);

        buildInitialRoutes();

        rootPanel.add(buildWelcomePanel(), "welcome");
        rootPanel.add(buildTransportPanel(), "transport");
        rootPanel.add(buildCleaningPanel(), "cleaning");
        rootPanel.add(buildPowerPanel(), "power");
        rootPanel.add(buildEmergencyPanel(), "emergency");

        add(rootPanel);
    }

    private void setupInitialEmergencyData() {
        Ambulance amb1 = new Ambulance("MC-101");
        amb1.addStaff(new Paramedic("Alice"));
        ambulanceService.addAmbulance(amb1);

        Ambulance amb2 = new Ambulance("MC-102");
        amb2.addStaff(new Paramedic("Bob"));
        ambulanceService.addAmbulance(amb2);
    }

    private static void initSampleData() {
        // Create and save some citizens
        Citizen c1 = new Citizen("Alice");
        Citizen c2 = new Citizen("Bob");
        try {
            c1.register(STORE);
            c2.register(STORE);
        } catch (Exception ignored) {}

        // Generate some sample bills for testing
        Admin admin = new Admin("moiz", "12345");
        admin.generateMonthlyBill(c1.getId(), STORE);
        admin.generateMonthlyBill(c2.getId(), STORE);

        // Create some power schedules for predefined areas
        STORE.saveSchedule(new PowerSchedule("Chatha Bakhtawar", LocalDate.now().plusDays(1)));
        STORE.saveSchedule(new PowerSchedule("Hostel city", LocalDate.now().plusDays(2)));
        STORE.saveSchedule(new PowerSchedule("Tramri", LocalDate.now().plusDays(3)));
    }

    // Welcome Panel
    private JPanel buildWelcomePanel() {
        JPanel welcomePanel = new JPanel(new BorderLayout());
        JLabel welcomeLabel = new JLabel("<html><h1>Welcome to Smart City Dashboard</h1><br>" +
                "Select a module from the menu.</html>", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Inter", Font.BOLD, 24));
        welcomePanel.add(welcomeLabel, BorderLayout.CENTER);

        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        JButton transportBtn = new JButton("Transport");
        JButton cleaningBtn = new JButton("Cleaning");
        JButton powerBtn = new JButton("Power");
        JButton emergencyBtn = new JButton("Emergency");

        menuPanel.add(transportBtn);
        menuPanel.add(cleaningBtn);
        menuPanel.add(powerBtn);
        menuPanel.add(emergencyBtn);

        welcomePanel.add(menuPanel, BorderLayout.SOUTH);

        transportBtn.addActionListener(e -> layout.show(rootPanel, "transport"));
        cleaningBtn.addActionListener(e -> layout.show(rootPanel, "cleaning"));
        powerBtn.addActionListener(e -> layout.show(rootPanel, "power"));
        emergencyBtn.addActionListener(e -> layout.show(rootPanel, "emergency"));

        return welcomePanel;
    }

    // Transport Panel
    private JPanel buildTransportPanel() {
        JPanel card = new JPanel(new CardLayout());
        JPanel chooser = new JPanel();
        JButton admin = new JButton("Login as Admin");
        JButton citizen = new JButton("Login as Citizen");
        chooser.add(admin);
        chooser.add(citizen);

        JPanel adminLoginPanel = new JPanel(new GridLayout(0, 2, 12, 12));
        JTextField username = new JTextField();
        JPasswordField password = new JPasswordField();
        JButton login = new JButton("Login");
        JLabel status = new JLabel();
        status.setFont(new Font("Inter", Font.PLAIN, 14));
        adminLoginPanel.add(new JLabel("Username:"));
        adminLoginPanel.add(username);
        adminLoginPanel.add(new JLabel("Password:"));
        adminLoginPanel.add(password);
        adminLoginPanel.add(login);
        adminLoginPanel.add(status);

        JPanel adminPanel = new JPanel(new BorderLayout(16, 16));
        JTextArea adminOutput = new JTextArea(10, 60);
        adminOutput.setEditable(false);
        JScrollPane adminScroll = new JScrollPane(adminOutput);

        JTextField newFare = new JTextField();
        JTextField startPoint = new JTextField();
        JTextField destPoint = new JTextField();
        JTextField destDist = new JTextField();
        JButton updateFare = new JButton("Update Fare/km");
        JButton addStart = new JButton("Add Start Point");
        JButton addDest = new JButton("Add Destination to Start Point");
        JButton viewRoutes = new JButton("View Routes");

        JPanel adminForm = new JPanel(new GridLayout(0, 2, 12, 12));
        adminForm.add(new JLabel("New Fare/km:"));
        adminForm.add(newFare);
        adminForm.add(new JLabel("Start Point:"));
        adminForm.add(startPoint);
        adminForm.add(new JLabel("Destination:"));
        adminForm.add(destPoint);
        adminForm.add(new JLabel("Distance (km):"));
        adminForm.add(destDist);
        adminForm.add(updateFare);
        adminForm.add(addStart);
        adminForm.add(addDest);
        adminForm.add(viewRoutes);

        adminPanel.add(adminForm, BorderLayout.NORTH);
        adminPanel.add(adminScroll, BorderLayout.CENTER);

        JPanel citizenPanel = new JPanel(new BorderLayout(16, 16));
        JTextArea output = new JTextArea(10, 60);
        output.setEditable(false);
        JScrollPane scroll = new JScrollPane(output);
        JComboBox<String> sourceBox = new JComboBox<>();
        JComboBox<String> destBox = new JComboBox<>();
        JButton getRoutes = new JButton("Show Destinations");
        JButton calculateFare = new JButton("Calculate Fare");

        JPanel form = new JPanel(new GridLayout(0, 2, 12, 12));
        form.add(new JLabel("Select Start Point:"));
        form.add(sourceBox);
        form.add(getRoutes);
        form.add(new JLabel("Destination Options:"));
        form.add(destBox);
        form.add(calculateFare);

        citizenPanel.add(form, BorderLayout.NORTH);
        citizenPanel.add(scroll, BorderLayout.CENTER);

        card.add(chooser, "chooseRole");
        card.add(adminLoginPanel, "adminLogin");
        card.add(adminPanel, "adminPanel");
        card.add(citizenPanel, "citizenPanel");

        CardLayout cl = (CardLayout) card.getLayout();

        updateSourceDropdown(sourceBox);

        admin.addActionListener(e -> cl.show(card, "adminLogin"));
        citizen.addActionListener(e -> cl.show(card, "citizenPanel"));

        login.addActionListener(e -> {
            if (username.getText().equals("admin") && new String(password.getPassword()).equals("admin123")) {
                status.setText("[CHECKMARK] Login Successful");
                cl.show(card, "adminPanel");
            } else {
                status.setText("[WARNING] Invalid credentials");
            }
        });

        updateFare.addActionListener(e -> {
            try {
                farePerKM = Double.parseDouble(newFare.getText());
                BufferedWriter writer = new BufferedWriter(new FileWriter(FARE_FILE));
                writer.write(String.valueOf(farePerKM));
                writer.close();
                adminOutput.setText("[CHECKMARK] Fare updated to Rs. " + farePerKM + "/km\n");
                showGoBackButton(adminPanel);
            } catch (Exception ex) {
                adminOutput.setText("[WARNING] Invalid fare input\n");
            }
        });

        addStart.addActionListener(e -> {
            String point = startPoint.getText().trim();
            if (!point.isEmpty()) {
                routes.putIfAbsent(point, new LinkedHashMap<>());
                adminOutput.append("[CHECKMARK] Starting point '" + point + "' added.\n");
                saveRoutesToFile();
                updateSourceDropdown(sourceBox);
                showGoBackButton(adminPanel);
            }
        });

        addDest.addActionListener(e -> {
            String from = startPoint.getText().trim();
            String to = destPoint.getText().trim();
            try {
                double dist = Double.parseDouble(destDist.getText());
                if (routes.containsKey(from)) {
                    routes.get(from).put(to, dist);
                    saveRoutesToFile();
                    adminOutput.append("[CHECKMARK] Destination '" + to + "' added to '" + from + "' with " + dist + " km.\n");
                    showGoBackButton(adminPanel);
                } else {
                    adminOutput.append("[WARNING] Starting point not found.\n");
                }
            } catch (Exception ex) {
                adminOutput.append("[WARNING] Invalid distance input.\n");
            }
        });

        viewRoutes.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            java.util.List<String> sortedStarts = new ArrayList<>(routes.keySet());
            Collections.sort(sortedStarts);
            for (String start : sortedStarts) {
                sb.append("From " + start + "\n");
                java.util.List<Map.Entry<String, Double>> sortedDestinations = new ArrayList<>(routes.get(start).entrySet());
                sortedDestinations.sort(Map.Entry.comparingByKey());
                for (Map.Entry<String, Double> dest : sortedDestinations) {
                    sb.append(" → " + dest.getKey() + " - " + dest.getValue() + " km\n");
                }
            }
            adminOutput.setText(sb.toString());
            showGoBackButton(adminPanel);
        });

        getRoutes.addActionListener(e -> {
            String src = (String) sourceBox.getSelectedItem();
            destBox.removeAllItems();
            if (src != null && routes.containsKey(src)) {
                java.util.List<Map.Entry<String, Double>> entries = new ArrayList<>(routes.get(src).entrySet());
                entries.sort(Map.Entry.comparingByKey());
                for (Map.Entry<String, Double> entry : entries) {
                    destBox.addItem(entry.getKey() + " - " + entry.getValue() + " km");
                }
                output.setText("Available destinations from " + src + " loaded.");
                showGoBackButton(citizenPanel);
            }
        });

        calculateFare.addActionListener(e -> {
            String sel = (String) destBox.getSelectedItem();
            if (sel != null && sel.contains("-")) {
                try {
                    double dist = Double.parseDouble(sel.split(" - ")[1].replace(" km", "").trim());
                    double fare = dist * farePerKM;
                    output.append("\nEstimated Fare: Rs. " + String.format("%.2f", fare));
                    showGoBackButton(citizenPanel);
                } catch (Exception ex) {
                    output.append("\n[WARNING] Error calculating fare.");
                }
            }
        });

        JButton backBtn = new JButton("Back to Menu");
        backBtn.addActionListener(e -> layout.show(rootPanel, "welcome"));
        JPanel south = new JPanel();
        south.add(backBtn);
        card.add(south, BorderLayout.SOUTH);

        return card;
    }

    // Cleaning Panel
    private JPanel buildCleaningPanel() {
        JPanel cleaningPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("<html><h2>Smart City Cleaning System</h2></html>", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Inter", Font.BOLD, 24));
        cleaningPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel loginPanel = new JPanel(new GridLayout(0, 2, 12, 12));
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton adminLoginBtn = new JButton("Login as Admin");
        JButton citizenLoginBtn = new JButton("Login as Citizen");
        JLabel loginStatus = new JLabel();

        loginPanel.add(new JLabel("Username:"));
        loginPanel.add(usernameField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passwordField);
        loginPanel.add(adminLoginBtn);
        loginPanel.add(citizenLoginBtn);
        loginPanel.add(loginStatus);

        cleaningPanel.add(loginPanel, BorderLayout.CENTER);

        adminLoginBtn.addActionListener(e -> {
            String inputUsername = usernameField.getText().trim();
            String inputPassword = new String(passwordField.getPassword()).trim();
            
            if (inputUsername.equals("moiz") && inputPassword.equals("12345")) {
                loginStatus.setText("Welcome Admin!");
                showAdminDashboard();
            } else {
                loginStatus.setText("Incorrect credentials.");
                passwordField.setText("");
            }
        });

        citizenLoginBtn.addActionListener(e -> {
            String citizenName = usernameField.getText().trim();
            if (!citizenName.isEmpty()) {
                loginStatus.setText("Welcome, " + citizenName + "!");
                showCitizenDashboard(citizenName);
            } else {
                loginStatus.setText("Please enter your name");
            }
        });

        JButton backBtn = new JButton("Back to Menu");
        backBtn.addActionListener(e -> layout.show(rootPanel, "welcome"));
        cleaningPanel.add(backBtn, BorderLayout.SOUTH);

        return cleaningPanel;
    }

    private void showAdminDashboard() {
        JPanel adminPanel = new JPanel(new BorderLayout());
        JTextArea adminOutput = new JTextArea(10, 60);
        adminOutput.setEditable(false);
        JScrollPane adminScroll = new JScrollPane(adminOutput);
        adminPanel.add(adminScroll, BorderLayout.CENTER);

        JPanel adminOptions = new JPanel(new GridLayout(0, 1));
        JButton assignStaffBtn = new JButton("Assign Staff");
        JButton receiveComplaintsBtn = new JButton("Receive & Solve Complaint");
        JButton checkStatusBtn = new JButton("Check Cleaning Status");
        JButton updateStatusBtn = new JButton("Update Area Cleaning Status");
        JButton generateReportBtn = new JButton("Generate Weekly Report");
        JButton viewFeedbackBtn = new JButton("View Feedback");
        JButton backBtn = new JButton("Back to Menu");

        adminOptions.add(assignStaffBtn);
        adminOptions.add(receiveComplaintsBtn);
        adminOptions.add(checkStatusBtn);
        adminOptions.add(updateStatusBtn);
        adminOptions.add(generateReportBtn);
        adminOptions.add(viewFeedbackBtn);
        adminOptions.add(backBtn);

        adminPanel.add(adminOptions, BorderLayout.WEST);

        assignStaffBtn.addActionListener(e -> assignStaff(adminOutput));
        receiveComplaintsBtn.addActionListener(e -> readComplaintsForAdmin(adminOutput));
        checkStatusBtn.addActionListener(e -> checkAreaStatus(adminOutput));
        updateStatusBtn.addActionListener(e -> updateAreaStatus(adminOutput));
        generateReportBtn.addActionListener(e -> {
            writeStringToFile("cleaningreport.dat", "Weekly cleaning report created.");
            adminOutput.append("Weekly report generated successfully.\n");
        });
        viewFeedbackBtn.addActionListener(e -> readFromFile("feedback.dat", "Citizen Feedback:", adminOutput));
        backBtn.addActionListener(e -> layout.show(rootPanel, "welcome"));

        JFrame adminFrame = new JFrame("Admin Dashboard");
        adminFrame.setContentPane(adminPanel);
        adminFrame.setSize(800, 600);
        adminFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        adminFrame.setVisible(true);
    }

    private void assignStaff(JTextArea adminOutput) {
        String staffName = JOptionPane.showInputDialog(this, "Enter staff name to assign:");
        if (staffName == null || staffName.trim().isEmpty()) {
            adminOutput.append("No staff name entered.\n");
            return;
        }
        String area = JOptionPane.showInputDialog(this, "Enter area to assign staff to:");
        if (area == null || area.trim().isEmpty()) {
            adminOutput.append("No area entered.\n");
            return;
        }
        writeStringToFile("staffassignments.dat", "Staff: " + staffName + " assigned to Area: " + area);
        adminOutput.append("Staff " + staffName + " assigned to " + area + ".\n");
    }

    private void showCitizenDashboard(String citizenName) {
        JPanel citizenPanel = new JPanel(new BorderLayout());
        JTextArea citizenOutput = new JTextArea(10, 60);
        citizenOutput.setEditable(false);
        JScrollPane citizenScroll = new JScrollPane(citizenOutput);
        citizenPanel.add(citizenScroll, BorderLayout.CENTER);

        JPanel citizenOptions = new JPanel(new GridLayout(0, 1));
        JButton fileComplaintBtn = new JButton("File Complaint");
        JButton checkStatusBtn = new JButton("Check Complaint Status");
        JButton viewScheduleBtn = new JButton("View Cleaning Schedule");
        JButton giveFeedbackBtn = new JButton("Give Feedback");
        JButton backBtn = new JButton("Back to Menu");

        citizenOptions.add(fileComplaintBtn);
        citizenOptions.add(checkStatusBtn);
        citizenOptions.add(viewScheduleBtn);
        citizenOptions.add(giveFeedbackBtn);
        citizenOptions.add(backBtn);

        citizenPanel.add(citizenOptions, BorderLayout.WEST);

        fileComplaintBtn.addActionListener(e -> {
            String complaint = JOptionPane.showInputDialog("Enter your complaint:");
            if (complaint != null && !complaint.trim().isEmpty()) {
                writeStringToFile("complaints.dat", "Complaint by " + citizenName + ": " + complaint);
                citizenOutput.append("Complaint filed successfully.\n");
            }
        });
        
        checkStatusBtn.addActionListener(e -> readFromFile("complaints.dat", "Your Complaints:", citizenOutput));
        
        viewScheduleBtn.addActionListener(e -> {
            String schedule = "Monday - I-8 Markaz\nTuesday - Taramri Chowk\nWednesday - Hostel City\n" +
                             "Thursday - Faizabad\nFriday - E-11\nSaturday - PIMS Hospital\nSunday - D-12 Streets";
            citizenOutput.setText("\nCleaning Schedule:\n" + schedule);
        });
        
        giveFeedbackBtn.addActionListener(e -> {
            String feedback = JOptionPane.showInputDialog("Enter feedback:");
            if (feedback != null && !feedback.trim().isEmpty()) {
                writeStringToFile("feedback.dat", "Feedback by " + citizenName + ": " + feedback);
                citizenOutput.append("Feedback submitted successfully.\n");
            }
        });
        
        backBtn.addActionListener(e -> layout.show(rootPanel, "welcome"));

        JFrame citizenFrame = new JFrame("Citizen Dashboard - " + citizenName);
        citizenFrame.setContentPane(citizenPanel);
        citizenFrame.setSize(800, 600);
        citizenFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        citizenFrame.setVisible(true);
    }

    private void readComplaintsForAdmin(JTextArea adminOutput) {
        StringBuilder sb = new StringBuilder();
        sb.append("Complaints Received:\n");
        try (BufferedReader reader = new BufferedReader(new FileReader("complaints.dat"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        } catch (FileNotFoundException e) {
            sb.append("No complaints found.\n");
        } catch (IOException e) {
            sb.append("Error reading complaints file: ").append(e.getMessage()).append("\n");
        }
        adminOutput.setText(sb.toString());
    }

    private void updateAreaStatus(JTextArea adminOutput) {
        String area = JOptionPane.showInputDialog(this, "Enter area to update cleaning status:");
        if (area != null && !area.trim().isEmpty()) {
            String[] options = {"Cleaned", "Pending", "In Progress"};
            String status = (String) JOptionPane.showInputDialog(this, "Select new status for " + area + ":", "Update Status",
                    JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (status != null) {
                writeStringToFile("areastatus.dat", "Area: " + area + " | Status: " + status);
                adminOutput.append("Status for " + area + " updated to: " + status + "\n");
            }
        }
    }

    private void checkAreaStatus(JTextArea adminOutput) {
        StringBuilder sb = new StringBuilder();
        sb.append("Area Cleaning Status:\n");
        try (BufferedReader reader = new BufferedReader(new FileReader("areastatus.dat"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        } catch (FileNotFoundException e) {
            sb.append("No area status data found.\n");
        } catch (IOException e) {
            sb.append("Error reading area status file: ").append(e.getMessage()).append("\n");
        }
        adminOutput.setText(sb.toString());
    }

    // Power Panel
    private JPanel buildPowerPanel() {
        JPanel card = new JPanel(new CardLayout());
        JPanel chooser = new JPanel();
        JButton admin = new JButton("Login as Admin");
        JButton citizen = new JButton("Login as Citizen");
        chooser.add(admin);
        chooser.add(citizen);

        JPanel adminLoginPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Admin Login", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        adminLoginPanel.add(titleLabel, gbc);
        
        JTextField idField = new JTextField(20);
        JPasswordField pwdField = new JPasswordField(20);
        
        adminLoginPanel.add(new JLabel("Admin ID:"), gbc);
        adminLoginPanel.add(idField, gbc);
        adminLoginPanel.add(new JLabel("Password:"), gbc);
        adminLoginPanel.add(pwdField, gbc);
        
        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(e -> {
            try {
                Admin adminUser = new Admin(idField.getText(), new String(pwdField.getPassword()));
                adminUser.login(STORE);
                currentUser = adminUser;
                showAdminMenu(card);
            } catch (AuthenticationException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Login Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> layout.show(rootPanel, "welcome"));
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(loginButton);
        buttonPanel.add(backButton);
        
        adminLoginPanel.add(buttonPanel, gbc);

        JPanel citizenLoginPanel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        titleLabel = new JLabel("Citizen Login", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        citizenLoginPanel.add(titleLabel, gbc);
        
        JTextField nameField = new JTextField(20);
        
        citizenLoginPanel.add(new JLabel("Citizen Name:"), gbc);
        citizenLoginPanel.add(nameField, gbc);
        
        JButton registerButton = new JButton("Register/Login");
        registerButton.addActionListener(e -> {
            try {
                Citizen citizenUser = new Citizen(nameField.getText());
                citizenUser.register(STORE);
                currentUser = citizenUser;
                showCitizenMenu(card);
            } catch (DataAccessException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Registration Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        backButton = new JButton("Back");
        backButton.addActionListener(e -> layout.show(rootPanel, "welcome"));
        
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(registerButton);
        buttonPanel.add(backButton);
        
        citizenLoginPanel.add(buttonPanel, gbc);

        card.add(chooser, "chooseRole");
        card.add(adminLoginPanel, "adminLogin");
        card.add(citizenLoginPanel, "citizenLogin");

        CardLayout cl = (CardLayout) card.getLayout();

        admin.addActionListener(e -> cl.show(card, "adminLogin"));
        citizen.addActionListener(e -> cl.show(card, "citizenLogin"));

        JButton mainBackBtn = new JButton("Back to Menu");
        mainBackBtn.addActionListener(e -> layout.show(rootPanel, "welcome"));
        JPanel south = new JPanel();
        south.add(mainBackBtn);
        card.add(south, BorderLayout.SOUTH);

        return card;
    }

    private void showAdminMenu(JPanel parentCard) {
        JPanel adminPanel = new JPanel(new BorderLayout());
        
        JLabel titleLabel = new JLabel("Admin Menu", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        adminPanel.add(titleLabel, BorderLayout.NORTH);
        
        JPanel buttonPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        String[] options = {
            "Calculate Bill", "Generate Monthly Bill", "Add Late Fee", "View All Bills",
            "Create Power Schedule", "Assign Technician", "View Fault Reports", "Resolve Fault",
            "Add Connection Request", "Approve Connection"
        };
        
        for (String option : options) {
            JButton button = new JButton(option);
            button.addActionListener(new AdminMenuListener(option, parentCard));
            buttonPanel.add(button);
        }
        
        JButton backButton = new JButton("Logout");
        backButton.addActionListener(e -> {
            currentUser = null;
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "chooseRole");
        });
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(backButton);
        
        adminPanel.add(new JScrollPane(buttonPanel), BorderLayout.CENTER);
        adminPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        parentCard.add(adminPanel, "adminMenu");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "adminMenu");
    }

    private class AdminMenuListener implements ActionListener {
        private String option;
        private JPanel parentCard;
        
        public AdminMenuListener(String option, JPanel parentCard) {
            this.option = option;
            this.parentCard = parentCard;
        }
        
        @Override
        public void actionPerformed(ActionEvent e) {
            Admin admin = (Admin) currentUser;
            
            switch (option) {
                case "Calculate Bill":
                    showCalculateBillPanel(admin, parentCard);
                    break;
                case "Generate Monthly Bill":
                    showGenerateMonthlyBillPanel(admin, parentCard);
                    break;
                case "Add Late Fee":
                    showAddLateFeePanel(admin, parentCard);
                    break;
                case "View All Bills":
                    showAllBillsPanel(admin, parentCard);
                    break;
                case "Create Power Schedule":
                    showCreatePowerSchedulePanel(admin, parentCard);
                    break;
                case "Assign Technician":
                    showAssignTechnicianPanel(admin, parentCard);
                    break;
                case "View Fault Reports":
                    showFaultReportsPanel(admin, parentCard);
                    break;
                case "Resolve Fault":
                    showResolveFaultPanel(admin, parentCard);
                    break;
                case "Add Connection Request":
                    showAddConnectionRequestPanel(admin, parentCard);
                    break;
                case "Approve Connection":
                    showApproveConnectionPanel(admin, parentCard);
                    break;
            }
        }
    }

    private void showCalculateBillPanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Calculate Bill", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField unitsField = new JTextField(10);
        panel.add(new JLabel("Units used:"), gbc);
        panel.add(unitsField, gbc);
        
        JButton calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(e -> {
            try {
                int units = Integer.parseInt(unitsField.getText());
                double billAmount = admin.calculateBill(units);
                JOptionPane.showMessageDialog(this, 
                    "Calculated bill = Rs. " + billAmount, 
                    "Bill Calculation", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid number for units", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(calculateButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "calculateBill");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "calculateBill");
    }

    private void showGenerateMonthlyBillPanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Generate Monthly Bill", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField userIdField = new JTextField(10);
        panel.add(new JLabel("User ID:"), gbc);
        panel.add(userIdField, gbc);
        
        JButton generateButton = new JButton("Generate Bill");
        generateButton.addActionListener(e -> {
            try {
                int userId = Integer.parseInt(userIdField.getText());
                admin.generateMonthlyBill(userId, STORE);
                JOptionPane.showMessageDialog(this, 
                    "Monthly bill generated for user " + userId, 
                    "Bill Generated", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid user ID", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(generateButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "generateBill");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "generateBill");
    }

    private void showAddLateFeePanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Add Late Fee", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField billIdField = new JTextField(10);
        panel.add(new JLabel("Bill ID:"), gbc);
        panel.add(billIdField, gbc);
        
        JButton addButton = new JButton("Add Late Fee");
        addButton.addActionListener(e -> {
            try {
                int billId = Integer.parseInt(billIdField.getText());
                admin.addLateFee(billId, STORE);
                JOptionPane.showMessageDialog(this, 
                    "Late fee added to bill " + billId, 
                    "Late Fee Added", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid bill ID", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(addButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "addLateFee");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "addLateFee");
    }

    private void showAllBillsPanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new BorderLayout());
        
        JLabel titleLabel = new JLabel("All Bills", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        List<Bill> bills = admin.viewAllBills(STORE);
        String[] columnNames = {"ID", "User ID", "Amount", "Due Date", "Status"};
        Object[][] data = new Object[bills.size()][5];
        
        for (int i = 0; i < bills.size(); i++) {
            Bill bill = bills.get(i);
            data[i][0] = bill.getId();
            data[i][1] = bill.getUserId();
            data[i][2] = bill.getAmount();
            data[i][3] = bill.getDueDate();
            data[i][4] = bill.getStatus();
        }
        
        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(backButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        parentCard.add(panel, "allBills");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "allBills");
    }

    private void showCreatePowerSchedulePanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Create Power Schedule", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField areaField = new JTextField(20);
        JTextField dateField = new JTextField(20);
        
        panel.add(new JLabel("Area:"), gbc);
        panel.add(areaField, gbc);
        panel.add(new JLabel("Date (yyyy-mm-dd):"), gbc);
        panel.add(dateField, gbc);
        
        JButton createButton = new JButton("Create Schedule");
        createButton.addActionListener(e -> {
            try {
                String area = areaField.getText();
                LocalDate date = LocalDate.parse(dateField.getText());
                admin.createPowerSchedule(area, date, STORE);
                JOptionPane.showMessageDialog(this, 
                    "Power schedule created for " + area + " on " + date, 
                    "Schedule Created", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Invalid date format. Please use yyyy-mm-dd", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(createButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "createSchedule");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "createSchedule");
    }

    private void showAssignTechnicianPanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Assign Technician", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField faultIdField = new JTextField(10);
        JTextField techIdField = new JTextField(10);
        
        panel.add(new JLabel("Fault ID:"), gbc);
        panel.add(faultIdField, gbc);
        panel.add(new JLabel("Technician ID:"), gbc);
        panel.add(techIdField, gbc);
        
        JButton assignButton = new JButton("Assign Technician");
        assignButton.addActionListener(e -> {
            try {
                int faultId = Integer.parseInt(faultIdField.getText());
                int techId = Integer.parseInt(techIdField.getText());
                admin.assignTechnician(faultId, techId, STORE);
                JOptionPane.showMessageDialog(this, 
                    "Technician " + techId + " assigned to fault " + faultId, 
                    "Technician Assigned", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter valid IDs", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(assignButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "assignTech");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "assignTech");
    }

    private void showFaultReportsPanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new BorderLayout());
        
        JLabel titleLabel = new JLabel("Fault Reports", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        List<FaultReport> faults = admin.viewFaultReports(STORE);
        String[] columnNames = {"ID", "Issue", "Area", "Technician ID", "Status", "Reported By"};
        Object[][] data = new Object[faults.size()][6];
        
        for (int i = 0; i < faults.size(); i++) {
            FaultReport fault = faults.get(i);
            data[i][0] = fault.getId();
            data[i][1] = fault.getIssue();
            data[i][2] = fault.getArea();
            data[i][3] = fault.getTechnicianId();
            data[i][4] = fault.getStatus();
            data[i][5] = fault.getReportedBy();
        }
        
        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(backButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        parentCard.add(panel, "faultReports");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "faultReports");
    }

    private void showResolveFaultPanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Resolve Fault", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField faultIdField = new JTextField(10);
        panel.add(new JLabel("Fault ID:"), gbc);
        panel.add(faultIdField, gbc);
        
        JButton resolveButton = new JButton("Resolve Fault");
        resolveButton.addActionListener(e -> {
            try {
                int faultId = Integer.parseInt(faultIdField.getText());
                admin.resolveFault(faultId, STORE);
                JOptionPane.showMessageDialog(this, 
                    "Fault " + faultId + " resolved", 
                    "Fault Resolved", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid fault ID", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(resolveButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "resolveFault");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "resolveFault");
    }

    private void showAddConnectionRequestPanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Add Connection Request", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField userIdField = new JTextField(10);
        panel.add(new JLabel("User ID:"), gbc);
        panel.add(userIdField, gbc);
        
        JButton addButton = new JButton("Add Request");
        addButton.addActionListener(e -> {
            try {
                int userId = Integer.parseInt(userIdField.getText());
                admin.addConnectionRequest(userId, STORE);
                JOptionPane.showMessageDialog(this, 
                    "Connection request added for user " + userId, 
                    "Request Added", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid user ID", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(addButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "addConnection");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "addConnection");
    }

    private void showApproveConnectionPanel(Admin admin, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Approve Connection", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField requestIdField = new JTextField(10);
        panel.add(new JLabel("Request ID:"), gbc);
        panel.add(requestIdField, gbc);
        
        JButton approveButton = new JButton("Approve Connection");
        approveButton.addActionListener(e -> {
            try {
                int requestId = Integer.parseInt(requestIdField.getText());
                admin.approveConnection(requestId, STORE);
                JOptionPane.showMessageDialog(this, 
                    "Connection request " + requestId + " approved", 
                    "Request Approved", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid request ID", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "adminMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(approveButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "approveConnection");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "approveConnection");
    }

    private void showCitizenMenu(JPanel parentCard) {
        JPanel panel = new JPanel(new BorderLayout());
        
        JLabel titleLabel = new JLabel("Citizen Menu", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        JPanel buttonPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        String[] options = {
            "Request New Connection", "Report Fault", "Check Complaint Status", 
            "View Power Schedule", "View Bill", "Pay Bill", "Give Feedback"
        };
        
        for (String option : options) {
            JButton button = new JButton(option);
            button.addActionListener(new CitizenMenuListener(option, parentCard));
            buttonPanel.add(button);
        }
        
        JButton backButton = new JButton("Logout");
        backButton.addActionListener(e -> {
            currentUser = null;
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "chooseRole");
        });
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(backButton);
        
        panel.add(new JScrollPane(buttonPanel), BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        parentCard.add(panel, "citizenMenu");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "citizenMenu");
    }

    private class CitizenMenuListener implements ActionListener {
        private String option;
        private JPanel parentCard;
        
        public CitizenMenuListener(String option, JPanel parentCard) {
            this.option = option;
            this.parentCard = parentCard;
        }
        
        @Override
        public void actionPerformed(ActionEvent e) {
            Citizen citizen = (Citizen) currentUser;
            
            switch (option) {
                case "Request New Connection":
                    showRequestNewConnectionPanel(citizen, parentCard);
                    break;
                case "Report Fault":
                    showReportFaultPanel(citizen, parentCard);
                    break;
                case "Check Complaint Status":
                    showCheckComplaintStatusPanel(citizen, parentCard);
                    break;
                case "View Power Schedule":
                    showViewPowerSchedulePanel(citizen, parentCard);
                    break;
                case "View Bill":
                    showViewBillPanel(citizen, parentCard);
                    break;
                case "Pay Bill":
                    showPayBillPanel(citizen, parentCard);
                    break;
                case "Give Feedback":
                    showGiveFeedbackPanel(citizen, parentCard);
                    break;
            }
        }
    }

    private void showRequestNewConnectionPanel(Citizen citizen, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Request New Connection", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField addressField = new JTextField(20);
        panel.add(new JLabel("Address:"), gbc);
        panel.add(addressField, gbc);
        
        JButton requestButton = new JButton("Submit Request");
        requestButton.addActionListener(e -> {
            String address = addressField.getText();
            citizen.requestNewConnection(address, STORE);
            JOptionPane.showMessageDialog(this, 
                "New connection request submitted for address: " + address, 
                "Request Submitted", 
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "citizenMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(requestButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "requestConnection");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "requestConnection");
    }

    private void showReportFaultPanel(Citizen citizen, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Report Fault", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField issueField = new JTextField(20);
        JTextField areaField = new JTextField(20);
        
        panel.add(new JLabel("Issue:"), gbc);
        panel.add(issueField, gbc);
        panel.add(new JLabel("Area:"), gbc);
        panel.add(areaField, gbc);
        
        JButton reportButton = new JButton("Report Fault");
        reportButton.addActionListener(e -> {
            String issue = issueField.getText();
            String area = areaField.getText();
            int faultId = citizen.reportFault(issue, area, STORE);
            JOptionPane.showMessageDialog(this, 
                "Fault reported with ID: " + faultId, 
                "Fault Reported", 
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "citizenMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(reportButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "reportFault");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "reportFault");
    }

    private void showCheckComplaintStatusPanel(Citizen citizen, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Check Complaint Status", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField complaintIdField = new JTextField(10);
        panel.add(new JLabel("Complaint ID:"), gbc);
        panel.add(complaintIdField, gbc);
        
        JButton checkButton = new JButton("Check Status");
        checkButton.addActionListener(e -> {
            try {
                int complaintId = Integer.parseInt(complaintIdField.getText());
                String status = citizen.checkComplaintStatus(complaintId, STORE);
                JOptionPane.showMessageDialog(this, 
                    status, 
                    "Complaint Status", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid complaint ID", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "citizenMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(checkButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "checkComplaint");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "checkComplaint");
    }

    private void showViewPowerSchedulePanel(Citizen citizen, JPanel parentCard) {
        JPanel panel = new JPanel(new BorderLayout());
        
        JLabel titleLabel = new JLabel("View Power Schedule", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        // Area selection panel
        JPanel areaPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JComboBox<String> areaCombo = new JComboBox<>(new String[]{"Chatha Bakhtawar", "Hostel city", "Tramri"});
        JButton viewButton = new JButton("View Schedule");
        
        areaPanel.add(new JLabel("Select Area:"));
        areaPanel.add(areaCombo);
        areaPanel.add(viewButton);
        
        // Schedule display panel
        JTextArea scheduleArea = new JTextArea(10, 40);
        scheduleArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(scheduleArea);
        
        viewButton.addActionListener(e -> {
            String selectedArea = (String) areaCombo.getSelectedItem();
            List<PowerSchedule> schedules = citizen.viewPowerSchedule(selectedArea, STORE);
            
            if (schedules.isEmpty()) {
                scheduleArea.setText("No Power Schedule available for " + selectedArea + ".");
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("Power Schedule for ").append(selectedArea).append(":\n\n");
                for (PowerSchedule ps : schedules) {
                    sb.append(ps).append("\n\n");
                }
                scheduleArea.setText(sb.toString());
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "citizenMenu");
        });
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(areaPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(backButton, BorderLayout.SOUTH);
        
        panel.add(mainPanel, BorderLayout.CENTER);
        
        parentCard.add(panel, "viewSchedule");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "viewSchedule");
    }

    private void showViewBillPanel(Citizen citizen, JPanel parentCard) {
        JPanel panel = new JPanel(new BorderLayout());
        
        JLabel titleLabel = new JLabel("Your Bills", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        List<Bill> bills = citizen.viewBill(citizen.getId(), STORE);
        String[] columnNames = {"ID", "Amount", "Due Date", "Status"};
        Object[][] data = new Object[bills.size()][4];
        
        for (int i = 0; i < bills.size(); i++) {
            Bill bill = bills.get(i);
            data[i][0] = bill.getId();
            data[i][1] = bill.getAmount();
            data[i][2] = bill.getDueDate();
            data[i][3] = bill.getStatus();
        }
        
        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "citizenMenu");
        });
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(backButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        parentCard.add(panel, "viewBills");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "viewBills");
    }

    private void showPayBillPanel(Citizen citizen, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Pay Bill", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField billIdField = new JTextField(10);
        panel.add(new JLabel("Bill ID:"), gbc);
        panel.add(billIdField, gbc);
        
        JButton payButton = new JButton("Pay Bill");
        payButton.addActionListener(e -> {
            try {
                int billId = Integer.parseInt(billIdField.getText());
                citizen.payBill(billId, STORE);
                JOptionPane.showMessageDialog(this, 
                    "Bill " + billId + " paid successfully", 
                    "Payment Successful", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid bill ID", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "citizenMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(payButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "payBill");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "payBill");
    }

    private void showGiveFeedbackPanel(Citizen citizen, JPanel parentCard) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel titleLabel = new JLabel("Give Feedback", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, gbc);
        
        JTextField messageField = new JTextField(20);
        JTextField ratingField = new JTextField(5);
        
        panel.add(new JLabel("Message:"), gbc);
        panel.add(messageField, gbc);
        panel.add(new JLabel("Rating (1-5):"), gbc);
        panel.add(ratingField, gbc);
        
        JButton submitButton = new JButton("Submit Feedback");
        submitButton.addActionListener(e -> {
            try {
                String msg = messageField.getText();
                int rating = Integer.parseInt(ratingField.getText());
                if (rating < 1 || rating > 5) {
                    throw new NumberFormatException();
                }
                citizen.giveFeedback(msg, rating, STORE);
                JOptionPane.showMessageDialog(this, 
                    "Feedback submitted successfully", 
                    "Thank You", 
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter a valid rating (1-5)", 
                    "Input Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) parentCard.getLayout();
            cl.show(parentCard, "citizenMenu");
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(submitButton);
        buttonPanel.add(backButton);
        
        panel.add(buttonPanel, gbc);
        
        parentCard.add(panel, "giveFeedback");
        CardLayout cl = (CardLayout) parentCard.getLayout();
        cl.show(parentCard, "giveFeedback");
    }

    // Emergency Panel
    private JPanel buildEmergencyPanel() {
        JPanel emergencyPanel = new JPanel(new BorderLayout());
        emergencyPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Title
        JLabel titleLabel = new JLabel("Emergency Services Management", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Inter", Font.BOLD, 24));
        emergencyPanel.add(titleLabel, BorderLayout.NORTH);

        // Output area
        emergencyOutputArea = new JTextArea();
        emergencyOutputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(emergencyOutputArea);
        emergencyPanel.add(scrollPane, BorderLayout.CENTER);

        // Control panel
        JPanel controlPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));

        // Buttons for operations
        JButton addAmbulanceBtn = new JButton("Add Ambulance");
        JButton addStaffBtn = new JButton("Add Medical Staff");
        JButton viewAmbulancesBtn = new JButton("View Ambulances");
        JButton dispatchBtn = new JButton("Dispatch Ambulance");
        JButton markAvailableBtn = new JButton("Mark Ambulance Available");
        JButton backBtn = new JButton("Back to Menu");

        // Add action listeners
        addAmbulanceBtn.addActionListener(e -> addAmbulance());
        addStaffBtn.addActionListener(e -> addStaffToAmbulance());
        viewAmbulancesBtn.addActionListener(e -> viewAmbulances());
        dispatchBtn.addActionListener(e -> dispatchAmbulance());
        markAvailableBtn.addActionListener(e -> markAmbulanceAvailable());
        backBtn.addActionListener(e -> layout.show(rootPanel, "welcome"));

        // Add buttons to control panel
        controlPanel.add(addAmbulanceBtn);
        controlPanel.add(addStaffBtn);
        controlPanel.add(viewAmbulancesBtn);
        controlPanel.add(dispatchBtn);
        controlPanel.add(markAvailableBtn);
        controlPanel.add(backBtn);

        emergencyPanel.add(controlPanel, BorderLayout.WEST);

        return emergencyPanel;
    }

    // Emergency Services Methods
    private void addAmbulance() {
        String vehicleNumber = JOptionPane.showInputDialog(this, "Enter Ambulance vehicle number:");
        if (vehicleNumber != null && !vehicleNumber.trim().isEmpty()) {
            Ambulance amb = new Ambulance(vehicleNumber);
            ambulanceService.addAmbulance(amb);
            emergencyOutputArea.append("Ambulance added: " + amb + "\n");
        }
    }

    private void addStaffToAmbulance() {
        String ambIdStr = JOptionPane.showInputDialog(this, "Enter Ambulance ID:");
        if (ambIdStr == null || ambIdStr.trim().isEmpty()) return;
        
        try {
            int ambId = Integer.parseInt(ambIdStr);
            Ambulance amb = ambulanceService.getAllAmbulances().stream()
                    .filter(a -> a.getId() == ambId).findFirst().orElse(null);

            if (amb == null) {
                JOptionPane.showMessageDialog(this, "Ambulance not found.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String name = JOptionPane.showInputDialog(this, "Enter medical staff name:");
            if (name != null && !name.trim().isEmpty()) {
                Paramedic paramedic = new Paramedic(name);
                amb.addStaff(paramedic);
                ambulanceService.markAmbulanceAvailable(ambId);
                emergencyOutputArea.append("Paramedic added: " + paramedic.getName() + " to Ambulance ID " + ambId + "\n");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid ambulance ID.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewAmbulances() {
        List<Ambulance> ambulances = ambulanceService.getAllAmbulances();
        if (ambulances.isEmpty()) {
            emergencyOutputArea.append("No ambulances in the system.\n");
            return;
        }
        
        emergencyOutputArea.append("\n=== Current Ambulances ===\n");
        ambulances.forEach(amb -> {
            emergencyOutputArea.append(amb + "\n");
            emergencyOutputArea.append(" Staff:\n");
            amb.getStaff().forEach(staff -> emergencyOutputArea.append("  - " + staff + "\n"));
        });
    }

    private void dispatchAmbulance() {
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        
        JTextField nameField = new JTextField();
        JTextField ageField = new JTextField();
        JTextField conditionField = new JTextField();
        JTextField locationField = new JTextField();
        
        panel.add(new JLabel("Patient Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Patient Age:"));
        panel.add(ageField);
        panel.add(new JLabel("Patient Condition:"));
        panel.add(conditionField);
        panel.add(new JLabel("Emergency Location:"));
        panel.add(locationField);
        
        int result = JOptionPane.showConfirmDialog(this, panel, "Emergency Details", 
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                String condition = conditionField.getText();
                String location = locationField.getText();
                
                if (name.isEmpty() || condition.isEmpty() || location.isEmpty()) {
                    throw new IllegalArgumentException("All fields must be filled");
                }
                
                Patient patient = new Patient(name, age, condition);
                EmergencyRequest<Patient> request = new EmergencyRequest<>(patient, location);
                
                boolean dispatched = dispatcher.dispatchAmbulance(request);
                if (dispatched) {
                    emergencyOutputArea.append("Ambulance dispatched to " + location + " for " + name + "\n");
                } else {
                    emergencyOutputArea.append("Failed to dispatch ambulance - none available\n");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid age entered.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void markAmbulanceAvailable() {
        String ambIdStr = JOptionPane.showInputDialog(this, "Enter Ambulance ID to mark as available:");
        if (ambIdStr == null || ambIdStr.trim().isEmpty()) return;
        
        try {
            int ambId = Integer.parseInt(ambIdStr);
            ambulanceService.markAmbulanceAvailable(ambId);
            emergencyOutputArea.append("Ambulance " + ambId + " marked as available.\n");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid ambulance ID.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Helper Methods
    private void showGoBackButton(JPanel panel) {
        JButton goBackBtn = new JButton("Go Back");
        goBackBtn.addActionListener(e -> layout.show(rootPanel, "welcome"));
        panel.add(goBackBtn, BorderLayout.SOUTH);
        panel.revalidate();
        panel.repaint();
    }

    // Helper to write a string to a file (append mode)
    private void writeStringToFile(String fileName, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(content);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing to file " + fileName + ": " + e.getMessage());
        }
    }

    // Helper to read from a file and display in a JTextArea
    private void readFromFile(String fileName, String header, JTextArea outputArea) {
        StringBuilder sb = new StringBuilder();
        sb.append(header).append("\n");
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        } catch (FileNotFoundException e) {
            sb.append("No data found.\n");
        } catch (IOException e) {
            sb.append("Error reading file: ").append(e.getMessage()).append("\n");
        }
        outputArea.setText(sb.toString());
    }

    private void saveRoutesToFile() {
        try {
            FileOutputStream fos = new FileOutputStream(ROUTE_FILE);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(routes);
            oos.close();
            fos.close();
        } catch (Exception e) {
            System.out.println("Error saving routes: " + e.getMessage());
        }
    }

    private void updateSourceDropdown(JComboBox<String> sourceBox) {
        sourceBox.removeAllItems();
        java.util.List<String> sortedStarts = new ArrayList<>(routes.keySet());
        Collections.sort(sortedStarts);
        for (String start : sortedStarts) {
            sourceBox.addItem(start);
        }
    }

    private void buildInitialRoutes() {
        try {
            FileInputStream fis = new FileInputStream(ROUTE_FILE);
            ObjectInputStream ois = new ObjectInputStream(fis);
            routes = (Map<String, Map<String, Double>>) ois.readObject();
            ois.close();
            fis.close();
        } catch (Exception e) {
            routes.put("COMSATS University", new LinkedHashMap<>(Map.of("I-8 Markaz", 14.0, "F-6", 16.2, "E-11", 26.1, "D-12", 30.2, "PIMS", 17.3)));
            routes.put("Faizabad", new LinkedHashMap<>(Map.of("F-6", 10.0, "E-11", 15.7, "D-12", 21.0, "PIMS", 6.8)));
            routes.put("Khanna Pull", new LinkedHashMap<>(Map.of("F-6", 15.3, "E-11", 20.4, "D-12", 25.7, "PIMS", 11.5)));
        }

        try {
            BufferedReader reader = new BufferedReader(new FileReader(FARE_FILE));
            farePerKM = Double.parseDouble(reader.readLine());
            reader.close();
        } catch (Exception e) {
            farePerKM = 5.0;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SmartCityDashboard app = new SmartCityDashboard();
            app.setVisible(true);
        });
    }
}

// ====================== CORE DOMAIN & OOP LAYERS =========================

/* -- Abstract base class (Abstraction & Inheritance) -- */
abstract class BasePerson {
    protected static int COUNTER = 1;
    protected final int id;
    protected String name;

    protected BasePerson(String name) {
        this.id = COUNTER++;
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{id=" + id + ", name='" + name + '\'' + '}';
    }
}

/* Marker to unify Admin & Citizen for aggregation demo */
abstract class AbstractUser extends BasePerson {
    protected AbstractUser(String name) { super(name); }
}

/* -------------------- Interfaces  👉  Polymorphism ----------------------- */
interface Authenticator {
    void login(DataStore store) throws AuthenticationException;
}

interface AdminOps {
    double calculateBill(int unitsUsed);
    void generateMonthlyBill(int userId, DataStore store);
    void addLateFee(int billId, DataStore store);
    List<Bill> viewAllBills(DataStore store);
    void createPowerSchedule(String area, LocalDate date, DataStore store);
    void assignTechnician(int faultId, int techId, DataStore store);
    List<FaultReport> viewFaultReports(DataStore store);
    void resolveFault(int faultId, DataStore store);
    void addConnectionRequest(int userId, DataStore store);
    void approveConnection(int requestId, DataStore store);
}

interface CitizenOps {
    void register(DataStore store) throws DataAccessException;
    void requestNewConnection(String address, DataStore store);
    int reportFault(String issue, String area, DataStore store);
    String checkComplaintStatus(int complaintId, DataStore store);
    List<PowerSchedule> viewPowerSchedule(String area, DataStore store);
    List<Bill> viewBill(int userId, DataStore store);
    void payBill(int billId, DataStore store);
    void giveFeedback(String message, int rating, DataStore store);
}

/* ======================= Concrete User Classes =========================== */
class Admin extends AbstractUser implements Authenticator, AdminOps {
    private final String password;
    private static final String ADMIN_ID = "moiz";
    private static final String ADMIN_PWD = "12345";
    private static final double TAX_RATE = 0.17;

    public Admin(String name, String password) {
        super(name);
        this.password = password;
    }

    @Override
    public void login(DataStore store) throws AuthenticationException {
        if (!ADMIN_ID.equalsIgnoreCase(name) || !ADMIN_PWD.equals(password)) {
            throw new AuthenticationException("Invalid admin credentials!");
        }
        System.out.println("Admin logged in successfully.");
    }

    /* AdminOps implementation */
    @Override
    public double calculateBill(int unitsUsed) {
        double rate = unitsUsed <= 100 ? 10 : unitsUsed <= 200 ? 12 : unitsUsed <= 300 ? 15 : 20;
        return unitsUsed * rate * (1 + TAX_RATE);
    }

    @Override
    public void generateMonthlyBill(int userId, DataStore store) {
        int totalUnits = store.getUnitsForUser(userId);
        double amount = calculateBill(totalUnits);
        Bill bill = new Bill(store.nextBillId(), userId, amount, LocalDate.now().plusDays(15));
        store.saveBill(bill);
        System.out.println("Monthly bill generated: " + bill);
    }

    @Override
    public void addLateFee(int billId, DataStore store) {
        Bill b = store.findBill(billId);
        if (b == null) {
            System.out.println("Bill not found.");
            return;
        }
        if (LocalDate.now().isAfter(b.getDueDate())) {
            b.setAmount(b.getAmount() * 1.10);
            store.updateBill(b);
            System.out.println("Late fee added.");
        } else {
            System.out.println("Due date not passed yet.");
        }
    }

    @Override
    public List<Bill> viewAllBills(DataStore store) {
        return store.allBills();
    }

    @Override
    public void createPowerSchedule(String area, LocalDate date, DataStore store) {
        store.saveSchedule(new PowerSchedule(area, date));
        System.out.println("Power schedule created for area: " + area + " on " + date);
    }

    @Override
    public void assignTechnician(int faultId, int techId, DataStore store) {
        FaultReport fr = store.findFault(faultId);
        if (fr != null) {
            fr.setTechnicianId(techId);
            fr.setStatus("Assigned");
            store.updateFault(fr);
            System.out.println("Technician " + techId + " assigned to fault " + faultId);
        } else {
            System.out.println("Fault not found.");
        }
    }

    @Override
    public List<FaultReport> viewFaultReports(DataStore store) {
        return store.allFaults();
    }

    @Override
    public void resolveFault(int faultId, DataStore store) {
        FaultReport fr = store.findFault(faultId);
        if (fr != null) {
            fr.setStatus("Resolved");
            store.updateFault(fr);
            System.out.println("Fault " + faultId + " resolved.");
        } else {
            System.out.println("Fault not found.");
        }
    }

    @Override
    public void addConnectionRequest(int userId, DataStore store) {
        ConnectionRequest request = new ConnectionRequest(store.nextConnectionRequestId(), userId, "Pending");
        store.saveConnectionRequest(request);
        System.out.println("Connection request added for user " + userId);
    }

    @Override
    public void approveConnection(int requestId, DataStore store) {
        ConnectionRequest request = store.findConnectionRequest(requestId);
        if (request != null) {
            request.setStatus("Approved");
            store.updateConnectionRequest(request);
            System.out.println("Connection request " + requestId + " approved.");
        } else {
            System.out.println("Connection request not found.");
        }
    }
}

class Citizen extends AbstractUser implements CitizenOps {
    public Citizen(String name) {
        super(name);
    }

    @Override
    public void register(DataStore store) throws DataAccessException {
        try {
            store.saveCitizen(this);
            System.out.println("Citizen registered successfully: " + this.name);
        } catch (Exception e) {
            throw new DataAccessException("Failed to register citizen: " + e.getMessage());
        }
    }

    @Override
    public void requestNewConnection(String address, DataStore store) {
        ConnectionRequest request = new ConnectionRequest(store.nextConnectionRequestId(), this.id, "Pending");
        request.setAddress(address);
        store.saveConnectionRequest(request);
        System.out.println("New connection request submitted for address: " + address);
    }

    @Override
    public int reportFault(String issue, String area, DataStore store) {
        FaultReport fault = new FaultReport(store.nextFaultId(), issue, area);
        fault.setReportedBy(this.id);
        store.saveFaultReport(fault);
        return fault.getId();
    }

    @Override
    public String checkComplaintStatus(int complaintId, DataStore store) {
        FaultReport fault = store.findFault(complaintId);
        if (fault != null) {
            return "Complaint ID " + complaintId + " status: " + fault.getStatus();
        }
        return "Complaint not found.";
    }

    @Override
    public List<PowerSchedule> viewPowerSchedule(String area, DataStore store) {
        return store.getSchedulesByArea(area);
    }

    @Override
    public List<Bill> viewBill(int userId, DataStore store) {
        return store.getBillsByUserId(userId);
    }

    @Override
    public void payBill(int billId, DataStore store) {
        Bill bill = store.findBill(billId);
        if (bill != null) {
            bill.setStatus("Paid");
            store.updateBill(bill);
            System.out.println("Bill " + billId + " paid successfully.");
        } else {
            System.out.println("Bill not found.");
        }
    }

    @Override
    public void giveFeedback(String message, int rating, DataStore store) {
        if (rating < 1 || rating > 5) {
            System.out.println("Rating must be between 1-5.");
            return;
        }
        Feedback feedback = new Feedback(store.nextFeedbackId(), this.id, message, rating);
        store.saveFeedback(feedback);
        System.out.println("Feedback submitted successfully.");
    }
}

/* ======================= Data Model Classes =========================== */
class Bill {
    private int id;
    private int userId;
    private double amount;
    private LocalDate dueDate;
    private String status = "Unpaid";

    public Bill(int id, int userId, double amount, LocalDate dueDate) {
        this.id = id;
        this.userId = userId;
        this.amount = amount;
        this.dueDate = dueDate;
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public LocalDate getDueDate() { return dueDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "Bill{id=" + id + ", userId=" + userId + ", amount=" + amount + 
               ", dueDate=" + dueDate + ", status='" + status + "'}";
    }
}

class FaultReport {
    private int id;
    private String issue;
    private String area;
    private int technicianId = -1;
    private String status = "Reported";
    private int reportedBy;

    public FaultReport(int id, String issue, String area) {
        this.id = id;
        this.issue = issue;
        this.area = area;
    }

    public int getId() { return id; }
    public String getIssue() { return issue; }
    public String getArea() { return area; }
    public int getTechnicianId() { return technicianId; }
    public void setTechnicianId(int technicianId) { this.technicianId = technicianId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getReportedBy() { return reportedBy; }
    public void setReportedBy(int reportedBy) { this.reportedBy = reportedBy; }

    @Override
    public String toString() {
        return "FaultReport{id=" + id + ", issue='" + issue + "', area='" + area + 
               "', technicianId=" + technicianId + ", status='" + status + "'}";
    }
}

class PowerSchedule {
    private String area;
    private LocalDate date;
    private String timeSlot = "08:00-18:00";

    public PowerSchedule(String area, LocalDate date) {
        this.area = area;
        this.date = date;
    }

    public String getArea() { return area; }
    public LocalDate getDate() { return date; }
    public String getTimeSlot() { return timeSlot; }
    public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }

    @Override
    public String toString() {
        return "PowerSchedule{area='" + area + "', date=" + date + ", timeSlot='" + timeSlot + "'}";
    }
}

class ConnectionRequest {
    private int id;
    private int userId;
    private String status;
    private String address;
    private LocalDate requestDate;

    public ConnectionRequest(int id, int userId, String status) {
        this.id = id;
        this.userId = userId;
        this.status = status;
        this.requestDate = LocalDate.now();
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public LocalDate getRequestDate() { return requestDate; }

    @Override
    public String toString() {
        return "ConnectionRequest{id=" + id + ", userId=" + userId + 
               ", status='" + status + "', address='" + address + "'}";
    }
}

class Feedback {
    private int id;
    private int userId;
    private String message;
    private int rating;
    private LocalDate date;

    public Feedback(int id, int userId, String message, int rating) {
        this.id = id;
        this.userId = userId;
        this.message = message;
        this.rating = rating;
        this.date = LocalDate.now();
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public String getMessage() { return message; }
    public int getRating() { return rating; }
    public LocalDate getDate() { return date; }

    @Override
    public String toString() {
        return "Feedback{id=" + id + ", userId=" + userId + ", message='" + message + 
               "', rating=" + rating + ", date=" + date + "}";
    }
}

/* ======================= Exception Classes =========================== */
class AuthenticationException extends Exception {
    public AuthenticationException(String message) {
        super(message);
    }
}

class DataAccessException extends Exception {
    public DataAccessException(String message) {
        super(message);
    }
}

/* ======================= DataStore Interface & Implementation ========= */
interface DataStore {
    // Bill operations
    int getUnitsForUser(int userId);
    void saveBill(Bill bill);
    Bill findBill(int billId);
    void updateBill(Bill bill);
    List<Bill> allBills();
    List<Bill> getBillsByUserId(int userId);
    int nextBillId();
    
    // Schedule operations
    void saveSchedule(PowerSchedule schedule);
    List<PowerSchedule> getSchedulesByArea(String area);
    
    // Fault operations
    FaultReport findFault(int faultId);
    void updateFault(FaultReport faultReport);
    List<FaultReport> allFaults();
    void saveFaultReport(FaultReport faultReport);
    int nextFaultId();
    
    // Connection request operations
    void saveConnectionRequest(ConnectionRequest request);
    ConnectionRequest findConnectionRequest(int requestId);
    void updateConnectionRequest(ConnectionRequest request);
    int nextConnectionRequestId();
    
    // Citizen operations
    void saveCitizen(Citizen citizen);
    
    // Feedback operations
    void saveFeedback(Feedback feedback);
    int nextFeedbackId();
}

/* Simple FileDataStore implementation */
class FileDataStore implements DataStore {
    private final List<Bill> bills = new ArrayList<>();
    private final List<FaultReport> faults = new ArrayList<>();
    private final List<PowerSchedule> schedules = new ArrayList<>();
    private final List<ConnectionRequest> connectionRequests = new ArrayList<>();
    private final List<Citizen> citizens = new ArrayList<>();
    private final List<Feedback> feedbacks = new ArrayList<>();
    
    private int billCounter = 1;
    private int faultCounter = 1;
    private int connectionRequestCounter = 1;
    private int feedbackCounter = 1;

    @Override
    public int getUnitsForUser(int userId) {
        // dummy implementation, returns random units between 50-300
        return 50 + (int)(Math.random() * 250);
    }

    @Override
    public void saveBill(Bill bill) {
        bills.add(bill);
    }

    @Override
    public Bill findBill(int billId) {
        return bills.stream().filter(b -> b.getId() == billId).findFirst().orElse(null);
    }

    @Override
    public void updateBill(Bill bill) {
        for (int i = 0; i < bills.size(); i++) {
            if (bills.get(i).getId() == bill.getId()) {
                bills.set(i, bill);
                return;
            }
        }
    }

    @Override
    public List<Bill> allBills() {
        return new ArrayList<>(bills);
    }

    @Override
    public List<Bill> getBillsByUserId(int userId) {
        return bills.stream().filter(b -> b.getUserId() == userId).toList();
    }

    @Override
    public int nextBillId() {
        return billCounter++;
    }

    @Override
    public void saveSchedule(PowerSchedule schedule) {
        schedules.add(schedule);
    }

    @Override
    public List<PowerSchedule> getSchedulesByArea(String area) {
        return schedules.stream().filter(s -> s.getArea().equalsIgnoreCase(area)).toList();
    }

    @Override
    public FaultReport findFault(int faultId) {
        return faults.stream().filter(f -> f.getId() == faultId).findFirst().orElse(null);
    }

    @Override
    public void updateFault(FaultReport faultReport) {
        for (int i = 0; i < faults.size(); i++) {
            if (faults.get(i).getId() == faultReport.getId()) {
                faults.set(i, faultReport);
                return;
            }
        }
    }

    @Override
    public List<FaultReport> allFaults() {
        return new ArrayList<>(faults);
    }

    @Override
    public void saveFaultReport(FaultReport faultReport) {
        faults.add(faultReport);
    }

    @Override
    public int nextFaultId() {
        return faultCounter++;
    }

    @Override
    public void saveConnectionRequest(ConnectionRequest request) {
        connectionRequests.add(request);
    }

    @Override
    public ConnectionRequest findConnectionRequest(int requestId) {
        return connectionRequests.stream().filter(r -> r.getId() == requestId).findFirst().orElse(null);
    }

    @Override
    public void updateConnectionRequest(ConnectionRequest request) {
        for (int i = 0; i < connectionRequests.size(); i++) {
            if (connectionRequests.get(i).getId() == request.getId()) {
                connectionRequests.set(i, request);
                return;
            }
        }
    }

    @Override
    public int nextConnectionRequestId() {
        return connectionRequestCounter++;
    }

    @Override
    public void saveCitizen(Citizen citizen) {
        citizens.add(citizen);
    }

    @Override
    public void saveFeedback(Feedback feedback) {
        feedbacks.add(feedback);
    }

    @Override
    public int nextFeedbackId() {
        return feedbackCounter++;
    }
}

// Model Classes (should be in models package)
abstract class Person {
    protected static int COUNTER = 1;
    protected final int id;
    protected String name;

    protected Person(String name) {
        this.id = COUNTER++;
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{id=" + id + ", name='" + name + "'}";
    }
}

interface Employee {
    void work();
}

interface EmergencyResponder {
    void respondToEmergency(EmergencyRequest request);
}

class Dispatcher extends Person implements Employee {
    private AmbulanceService ambulanceService;

    public Dispatcher(String name, AmbulanceService ambulanceService) {
        super(name);
        this.ambulanceService = ambulanceService;
    }

    @Override
    public void work() {
        System.out.println(name + " is dispatching ambulances.");
    }

    public boolean dispatchAmbulance(EmergencyRequest request) {
        Ambulance ambulance = ambulanceService.getAvailableAmbulance();
        if (ambulance == null) {
            System.out.println("No available ambulances at the moment.");
            return false;
        }
        ambulance.respondToEmergency(request);
        ambulanceService.markAmbulanceBusy(ambulance.getId());
        return true;
    }
}

abstract class MedicalStaff extends Person implements Employee, EmergencyResponder {
    protected String specialization;

    public MedicalStaff(String name, String specialization) {
        super(name);
        this.specialization = specialization;
    }

    @Override
    public void work() {
        System.out.println(name + " (" + specialization + ") is on duty.");
    }
}

class Paramedic extends MedicalStaff {
    public Paramedic(String name) {
        super(name, "Paramedic");
    }

    @Override
    public void respondToEmergency(EmergencyRequest request) {
        System.out.println("Paramedic " + name + " responding to emergency at: " + request.getLocation());
    }
}

class Ambulance implements EmergencyResponder, Serializable {
    private final int id;
    private String vehicleNumber;
    private boolean available;
    private List<MedicalStaff> staff;
    private static int AMB_COUNTER = 1;

    public Ambulance(String vehicleNumber) {
        this.id = AMB_COUNTER++;
        this.vehicleNumber = vehicleNumber;
        this.available = true;
        this.staff = new ArrayList<>();
    }

    public int getId() { return id; }
    public String getVehicleNumber() { return vehicleNumber; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
    public void addStaff(MedicalStaff member) { staff.add(member); }
    public List<MedicalStaff> getStaff() { return staff; }

    @Override
    public void respondToEmergency(EmergencyRequest request) {
        System.out.println("Ambulance " + vehicleNumber + " dispatched to " + request.getLocation() + " with patient: " + request.getPatientName());
        for (MedicalStaff member : staff) {
            member.respondToEmergency(request);
        }
    }

    @Override
    public String toString() {
        return "Ambulance{id=" + id + ", vehicleNumber='" + vehicleNumber + "', available=" + available + ", staffCount=" + staff.size() + "}";
    }
}

class EmergencyRequest<T> implements Serializable {
    private static int REQUEST_COUNTER = 1;
    private final int requestId;
    private T patientInfo;
    private String location;
    private LocalDateTime requestTime;

    public EmergencyRequest(T patientInfo, String location) {
        this.requestId = REQUEST_COUNTER++;
        this.patientInfo = patientInfo;
        this.location = location;
        this.requestTime = LocalDateTime.now();
    }

    public int getRequestId() { return requestId; }
    public T getPatientInfo() { return patientInfo; }
    public String getPatientName() {
        if (patientInfo instanceof Patient) {
            return ((Patient) patientInfo).getName();
        } else {
            return patientInfo.toString();
        }
    }
    public String getLocation() { return location; }
    public LocalDateTime getRequestTime() { return requestTime; }

    @Override
    public String toString() {
        return "EmergencyRequest{id=" + requestId + ", patient=" + patientInfo + ", location='" + location + "', requestTime=" + requestTime + "}";
    }
}

class Patient {
    private String name;
    private int age;
    private String condition;

    public Patient(String name, int age, String condition) {
        this.name = name;
        this.age = age;
        this.condition = condition;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public String getCondition() { return condition; }

    @Override
    public String toString() {
        return "Patient{name='" + name + "', age=" + age + ", condition='" + condition + "'}";
    }
}

class AmbulanceService {
    private Map<Integer, Ambulance> ambulances;
    private final String dataFile = "ambulances.dat";

    public AmbulanceService() {
        ambulances = new HashMap<>();
        loadAmbulances();
    }

    public void addAmbulance(Ambulance amb) {
        ambulances.put(amb.getId(), amb);
        saveAmbulances();
    }

    public Ambulance getAvailableAmbulance() {
        for (Ambulance amb : ambulances.values()) {
            if (amb.isAvailable()) return amb;
        }
        return null;
    }

    public void markAmbulanceBusy(int ambulanceId) {
        Ambulance amb = ambulances.get(ambulanceId);
        if (amb != null) {
            amb.setAvailable(false);
            saveAmbulances();
        }
    }

    public void markAmbulanceAvailable(int ambulanceId) {
        Ambulance amb = ambulances.get(ambulanceId);
        if (amb != null) {
            amb.setAvailable(true);
            saveAmbulances();
        }
    }

    public List<Ambulance> getAllAmbulances() {
        return new ArrayList<>(ambulances.values());
    }

    private void saveAmbulances() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(dataFile))) {
            oos.writeObject(ambulances);
        } catch (IOException e) {
            System.err.println("Error saving ambulance data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadAmbulances() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(dataFile))) {
            ambulances = (Map<Integer, Ambulance>) ois.readObject();
        } catch (FileNotFoundException e) {
            ambulances = new HashMap<>();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading ambulance data: " + e.getMessage());
            ambulances = new HashMap<>();
        }
    }
}





