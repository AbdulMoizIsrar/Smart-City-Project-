import java.util.Scanner;
import models.CleaningCity;
import models.EmergencyServiceApp;
import models.PowerStation;
import models.TransportUnit;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean repeat = true;

        while (repeat) {
            System.out.println("\n=== 🔰 Smart City Resource Management System 🔰 ===");
            System.out.println("1. Transport System");
            System.out.println("2. Cleaning City System");
            System.out.println("3. Power Station System");
            System.out.println("4. Emergency Services System");
            System.out.print("Choose your service (1/2/3/4): ");

            try {
                int option = scanner.nextInt();
                scanner.nextLine(); // consume newline

                switch (option) {
                    case 1 -> {
                        System.out.println("\n🚍 Smart City Transport Service 🚍");
                        TransportUnit.main(null); // Directly call CLI-based Transport System
                    }
                    case 2 -> {
                        System.out.println("\n🧹 Smart City Cleaning Service 🧹");
                        CleaningCity.main(null);
                    }
                    case 3 -> {
                        System.out.println("\n⚡ Smart City Power Station Service ⚡");
                        PowerStation.main(null);
                    }
                    case 4 -> {
                        System.out.println("\n🚑 Smart City Emergency Services 🚑");
                        EmergencyServiceApp.main(null);
                    }
                    default -> System.out.println("❌ Invalid option selected. Please choose 1–4.");
                }
            } catch (Exception e) {
                System.out.println("❌ Error: Invalid input. Please enter a number.");
                scanner.nextLine(); // clear invalid input
            }

            System.out.print("\nDo you want to use another service? (yes/no): ");
            String again = scanner.nextLine();
            repeat = again.equalsIgnoreCase("yes");
        }

        scanner.close();
        System.out.println("✅ Thank you for using Smart City System. Goodbye!");
    }
}


