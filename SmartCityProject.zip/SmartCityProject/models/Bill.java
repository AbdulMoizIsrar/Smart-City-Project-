package models;

import java.time.LocalDate;

public class Bill {
    private int id;
    private int userId;
    private double amount;
    private LocalDate dueDate;

    public Bill(int id, int userId, double amount, LocalDate dueDate) {
        this.id = id;
        this.userId = userId;
        this.amount = amount;
        this.dueDate = dueDate;
    }

    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    @Override
    public String toString() {
        return "Bill{id=" + id + ", userId=" + userId + ", amount=" + amount + ", dueDate=" + dueDate + "}";
    }
}
