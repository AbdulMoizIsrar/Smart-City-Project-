
package models;

import java.io.*;
import java.util.*;

public class CleaningCity {
    private static final String ADMIN_USER = "moiz";
    private static final String ADMIN_PASS = "12345";

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("\n=== Smart City Cleaning System ===");
        System.out.println("1. Login as Admin");
        System.out.println("2. Login as Citizen");
        System.out.print("Choose option (1/2): ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        if (choice == 1) {
            boolean retry;
            do {
                retry = false;
                System.out.print("Enter Admin User ID: ");
                String user = scanner.nextLine();
                System.out.print("Enter Password: ");
                String pass = scanner.nextLine();

                if (user.equals(ADMIN_USER) && pass.equals(ADMIN_PASS)) {
                    System.out.println("\nWelcome Admin!\n");
                    adminDashboard();
                } else {
                    System.out.println("Incorrect credentials.");
                    retry = askRetry();
                }
            } while (retry);
        } else if (choice == 2) {
            loginCitizen();
        } else {
            System.out.println("Invalid option!");
        }
    }

    private static void adminDashboard() {
        boolean running = true;
        while (running) {
            System.out.println("--- Admin Dashboard ---");
            System.out.println("1. Assign Staff");
            System.out.println("2. Receive & Solve Complaint");
            System.out.println("3. Check Cleaning Status");
            System.out.println("4. Update Area Cleaning Status");
            System.out.println("5. Add/Manage Cleaning Vehicle");
            System.out.println("6. Generate Weekly Report");
            System.out.println("7. View Feedback");
            System.out.println("8. Exit");
            System.out.print("Enter choice: ");

            int opt = scanner.nextInt();
            scanner.nextLine();

            switch (opt) {
                case 1 -> assignStaff();
                case 2 -> readComplaintsForAdmin();
                case 3 -> checkAreaStatus();
                case 4 -> updateAreaStatus();
                case 5 -> System.out.println("Cleaning vehicle managed.");
                case 6 -> writeStringToFile("cleaningreport.dat", "Weekly cleaning report created.");
                case 7 -> readFromFile("feedback.dat", "Citizen Feedback:");
                case 8 -> running = false;
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static boolean askRetry() {
        System.out.print("Do you want to retry login? (yes/no): ");
        String response = scanner.nextLine();
        return response.equalsIgnoreCase("yes");
    }

    private static void assignStaff() {
        List<String> staffList = new ArrayList<>(Arrays.asList("Ali", "Ahmed", "Farhad", "Ahmer", "Pervaiz Khan"));
        File file = new File("staff.dat");

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            staffList = (List<String>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No previous staff found, using default list.");
        }

        System.out.println("\n--- Current Staff Members ---");
        for (String staff : staffList) {
            System.out.println("- " + staff);
        }

        System.out.print("\nDo you want to add a new staff member? (yes/no): ");
        String response = scanner.nextLine();
        if (response.equalsIgnoreCase("yes")) {
            System.out.print("Enter new staff member name: ");
            String newStaff = scanner.nextLine();
            staffList.add(newStaff);
            System.out.println("Staff member added successfully.");
        }

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(staffList);
            System.out.println("Updated staff list saved to staff.dat");
        } catch (IOException e) {
            System.out.println("Error saving staff file: " + e.getMessage());
        }
    }

    private static void checkAreaStatus() {
        Map<String, String> statusMap = new HashMap<>();
        File file = new File("areaStatus.dat");

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            statusMap = (Map<String, String>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No previous area status found.");
            return;
        }

        System.out.println("\n--- Area Cleaning Status ---");
        for (Map.Entry<String, String> entry : statusMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    private static void updateAreaStatus() {
        Map<String, String> statusMap = new HashMap<>();
        File file = new File("areaStatus.dat");

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            statusMap = (Map<String, String>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No previous area status found, starting fresh.");
        }

        System.out.print("Enter area name to update status: ");
        String area = scanner.nextLine();
        System.out.print("Enter new status (Cleaned/Pending/In Progress): ");
        String status = scanner.nextLine();
        statusMap.put(area, status);

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(statusMap);
            System.out.println("Area status updated in areaStatus.dat");
        } catch (IOException e) {
            System.out.println("Error writing area status: " + e.getMessage());
        }
    }

    private static void loginCitizen() {
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.println("Welcome, " + name + "!\n");

        boolean running = true;
        while (running) {
            System.out.println("--- Citizen Dashboard ---");
            System.out.println("1. File Complaint");
            System.out.println("2. Check Complaint Status");
            System.out.println("3. View Cleaning Schedule");
            System.out.println("4. Give Feedback");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            int opt = scanner.nextInt();
            scanner.nextLine();

            switch (opt) {
                case 1 -> writeStringToFile("complaints.dat", "Complaint by " + name + ": " + getInput("Enter your complaint: "));
                case 2 -> readFromFile("complaints.dat", "Complaints List:");
                case 3 -> showSchedule();
                case 4 -> writeStringToFile("feedback.dat", "Feedback by " + name + ": " + getInput("Enter feedback: "));
                case 5 -> running = false;
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void showSchedule() {
        String schedule = "Monday - I-8 Markaz\n" +
                          "Tuesday - Taramri Chowk\n" +
                          "Wednesday - Hostel City\n" +
                          "Thursday - Faizabad\n" +
                          "Friday - E-11\n" +
                          "Saturday - PIMS Hospital\n" +
                          "Sunday - D-12 Streets";

        System.out.println("\nCleaning Schedule:\n" + schedule);
        writeStringToFile("cleaningSchedule.dat", schedule);
    }

    private static void writeStringToFile(String filename, String content) {
        try (FileWriter fw = new FileWriter(filename, true); BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(content);
            bw.newLine();
            System.out.println("Saved to " + filename);
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    private static void readFromFile(String filename, String heading) {
        File file = new File(filename);
        if (!file.exists() || file.length() == 0) {
            System.out.println("No records found in " + filename);
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            System.out.println("\n" + heading);
            boolean hasContent = false;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    System.out.println("- " + line);
                    hasContent = true;
                }
            }
            if (!hasContent) {
                System.out.println("No records found in " + filename);
            }
        } catch (IOException e) {
            System.out.println("File not found or error reading file.");
        }
    }

    // New method to read complaints specifically for admin with empty check
    private static void readComplaintsForAdmin() {
        File file = new File("complaints.dat");
        if (!file.exists() || file.length() == 0) {
            System.out.println("No complaints submitted yet.");
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            System.out.println("\nComplaints:");
            String line;
            boolean hasComplaint = false;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    System.out.println("- " + line);
                    hasComplaint = true;
                }
            }
            if (!hasComplaint) {
                System.out.println("No complaints submitted yet.");
            }
        } catch (IOException e) {
            System.out.println("Error reading complaints file.");
        }
    }

    private static String getInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }
}