package models;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PowerStation {
    private static final Scanner SCANNER = new Scanner(System.in);
    private static final DataStore STORE = new FileDataStore();
    private static AbstractUser currentUser; // Demonstrates aggregation: User exists independently

    public static void main(String[] args) {
        // Initialize with some sample data for testing
        initSampleData();

        while (true) {
            try {
                System.out.println("\n=== Welcome to Smart City Power Station ===");
                System.out.println("1. Login as Admin");
                System.out.println("2. Login as Citizen");
                System.out.println("0. Exit");
                System.out.print("Select option: ");
                int option = Integer.parseInt(SCANNER.nextLine());
                switch (option) {
                    case 1 -> adminLogin();
                    case 2 -> citizenLogin();
                    case 0 -> System.exit(0);
                    default -> System.out.println("Invalid selection.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private static void initSampleData() {
        // Create and save some citizens
        Citizen c1 = new Citizen("Alice");
        Citizen c2 = new Citizen("Bob");
        try {
            c1.register(STORE);
            c2.register(STORE);
        } catch (Exception ignored) {}

        // Generate some sample bills for testing
        Admin admin = new Admin("moiz", "12345");
        admin.generateMonthlyBill(c1.getId(), STORE);
        admin.generateMonthlyBill(c2.getId(), STORE);

        // Create some power schedules for predefined areas
        STORE.saveSchedule(new PowerSchedule("Chatha Bakhtawar", LocalDate.now().plusDays(1)));
        STORE.saveSchedule(new PowerSchedule("Hostel city", LocalDate.now().plusDays(2)));
        STORE.saveSchedule(new PowerSchedule("Tramri", LocalDate.now().plusDays(3)));
    }

    /* -------------------------- LOGIN HANDLERS -------------------------------- */

    private static void adminLogin() {
        try {
            System.out.print("Admin ID: ");
            String id = SCANNER.nextLine();
            System.out.print("Password: ");
            String pwd = SCANNER.nextLine();
            Admin admin = new Admin(id, pwd);
            admin.login(STORE); // validate credentials
            currentUser = admin;
            adminMenu(admin);
        } catch (AuthenticationException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void citizenLogin() {
        try {
            System.out.print("Citizen Name: ");
            String name = SCANNER.nextLine();
            Citizen citizen = new Citizen(name);
            citizen.register(STORE); // append name to file
            currentUser = citizen;
            citizenMenu(citizen);
        } catch (DataAccessException e) {
            System.out.println(e.getMessage());
        }
    }

    /* ---------------------------- MENUS --------------------------------------- */

    private static void adminMenu(Admin admin) {
        while (true) {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Calculate Bill");
            System.out.println("2. Generate Monthly Bill");
            System.out.println("3. Add Late Fee");
            System.out.println("4. View All Bills");
            System.out.println("5. Create Power Schedule");
            System.out.println("6. Assign Technician");
            System.out.println("7. View Fault Reports");
            System.out.println("8. Resolve Fault");
            System.out.println("9. Add Connection Request");
            System.out.println("10. Approve Connection");
            System.out.println("0. Logout");
            System.out.print("Option: ");
            try {
                int op = Integer.parseInt(SCANNER.nextLine());
                switch (op) {
                    case 1 -> {
                        System.out.print("Units used: ");
                        int units = Integer.parseInt(SCANNER.nextLine());
                        double billAmount = admin.calculateBill(units);
                        System.out.println("Calculated bill = Rs. " + billAmount);
                    }
                    case 2 -> {
                        System.out.print("User ID: ");
                        int uid = Integer.parseInt(SCANNER.nextLine());
                        admin.generateMonthlyBill(uid, STORE);
                    }
                    case 3 -> {
                        System.out.print("Bill ID: ");
                        int bid = Integer.parseInt(SCANNER.nextLine());
                        admin.addLateFee(bid, STORE);
                    }
                    case 4 -> {
                        List<Bill> bills = admin.viewAllBills(STORE);
                        if (bills.isEmpty()) {
                            System.out.println("No bills found.");
                        } else {
                            System.out.println("All Bills:");
                            for (Bill b : bills) {
                                System.out.println(b);
                            }
                        }
                    }
                    case 5 -> {
                        System.out.print("Area: ");
                        String area = SCANNER.nextLine();
                        System.out.print("Date (yyyy-mm-dd): ");
                        LocalDate date = LocalDate.parse(SCANNER.nextLine());
                        admin.createPowerSchedule(area, date, STORE);
                    }
                    case 6 -> {
                        System.out.print("Fault ID: ");
                        int fid = Integer.parseInt(SCANNER.nextLine());
                        System.out.print("Technician ID: ");
                        int tid = Integer.parseInt(SCANNER.nextLine());
                        admin.assignTechnician(fid, tid, STORE);
                    }
                    case 7 -> {
                        List<FaultReport> faults = admin.viewFaultReports(STORE);
                        if (faults.isEmpty()) {
                            System.out.println("No fault reports.");
                        } else {
                            for (FaultReport f : faults) {
                                System.out.println(f);
                            }
                        }
                    }
                    case 8 -> {
                        System.out.print("Fault ID: ");
                        int rf = Integer.parseInt(SCANNER.nextLine());
                        admin.resolveFault(rf, STORE);
                    }
                    case 9 -> {
                        System.out.print("User ID: ");
                        int u = Integer.parseInt(SCANNER.nextLine());
                        admin.addConnectionRequest(u, STORE);
                    }
                    case 10 -> {
                        System.out.print("Request ID: ");
                        int rid = Integer.parseInt(SCANNER.nextLine());
                        admin.approveConnection(rid, STORE);
                    }
                    case 0 -> {
                        return;
                    }
                    default -> System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void citizenMenu(Citizen citizen) {
        while (true) {
            System.out.println("\n--- Citizen Menu ---");
            System.out.println("1. Request New Connection");
            System.out.println("2. Report Fault");
            System.out.println("3. Check Complaint Status");
            System.out.println("4. View Power Schedule");
            System.out.println("5. View Bill");
            System.out.println("6. Pay Bill");
            System.out.println("7. Give Feedback");
            System.out.println("0. Logout");
            System.out.print("Option: ");
            try {
                int op = Integer.parseInt(SCANNER.nextLine());
                switch (op) {
                    case 1 -> {
                        System.out.print("Address: ");
                        String addr = SCANNER.nextLine();
                        citizen.requestNewConnection(addr, STORE);
                    }
                    case 2 -> {
                        System.out.print("Issue: ");
                        String issue = SCANNER.nextLine();
                        System.out.print("Area: ");
                        String area = SCANNER.nextLine();
                        int faultId = citizen.reportFault(issue, area, STORE);
                        System.out.println("Fault reported with ID: " + faultId);
                    }
                    case 3 -> {
                        System.out.print("Complaint ID: ");
                        int cid = Integer.parseInt(SCANNER.nextLine());
                        System.out.println(citizen.checkComplaintStatus(cid, STORE));
                    }
                    case 4 -> {
                        // Show list of predefined areas for power schedules
                        System.out.println("Select area to view power schedule:");
                        List<String> areas = List.of("Chatha Bakhtawar", "Hostel city", "Tramri");
                        for (int i = 0; i < areas.size(); i++) {
                            System.out.println((i+1) + ". " + areas.get(i));
                        }
                        System.out.print("Enter option (number): ");
                        int areaChoice = Integer.parseInt(SCANNER.nextLine());
                        if (areaChoice < 1 || areaChoice > areas.size()) {
                            System.out.println("Invalid area selection.");
                            break;
                        }
                        String selectedArea = areas.get(areaChoice - 1);
                        List<PowerSchedule> schedules = citizen.viewPowerSchedule(selectedArea, STORE);
                        if (schedules.isEmpty()) {
                            System.out.println("No Power Schedule available for " + selectedArea + ".");
                        } else {
                            System.out.println("Power Schedule for " + selectedArea + ":");
                            for (PowerSchedule ps : schedules) {
                                System.out.println(ps);
                            }
                        }
                    }
                    case 5 -> {
                        List<Bill> bills = citizen.viewBill(citizen.getId(), STORE);
                        if (bills.isEmpty()) {
                            System.out.println("No bills found.");
                        } else {
                            System.out.println("Your Bills:");
                            for (Bill b : bills) {
                                System.out.println(b);
                            }
                        }
                    }
                    case 6 -> {
                        System.out.print("Bill ID: ");
                        int bid = Integer.parseInt(SCANNER.nextLine());
                        citizen.payBill(bid, STORE);
                    }
                    case 7 -> {
                        System.out.print("Message: ");
                        String msg = SCANNER.nextLine();
                        System.out.print("Rating (1-5): ");
                        int rating = Integer.parseInt(SCANNER.nextLine());
                        citizen.giveFeedback(msg, rating, STORE);
                    }
                    case 0 -> {
                        return;
                    }
                    default -> System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}

/* ====================== CORE DOMAIN & OOP LAYERS ========================= */

/* -- Abstract base class (Abstraction & Inheritance) -- */
abstract class BasePerson {
    protected static int COUNTER = 1;
    protected final int id;
    protected String name;

    protected BasePerson(String name) {
        this.id = COUNTER++;
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{" + "id=" + id + ", name='" + name + '\'' + '}';
    }
}

/* Marker to unify Admin & Citizen for aggregation demo */
abstract class AbstractUser extends BasePerson {
    protected AbstractUser(String name) { super(name); }
}

/* -------------------- Interfaces  👉  Polymorphism ----------------------- */
interface Authenticator {
    void login(DataStore store) throws AuthenticationException;
}

interface AdminOps {
    double calculateBill(int unitsUsed);
    void generateMonthlyBill(int userId, DataStore store);
    void addLateFee(int billId, DataStore store);
    List<Bill> viewAllBills(DataStore store);
    void createPowerSchedule(String area, LocalDate date, DataStore store);
    void assignTechnician(int faultId, int techId, DataStore store);
    List<FaultReport> viewFaultReports(DataStore store);
    void resolveFault(int faultId, DataStore store);
    void addConnectionRequest(int userId, DataStore store);
    void approveConnection(int requestId, DataStore store);
}

interface CitizenOps {
    void register(DataStore store) throws DataAccessException;
    void requestNewConnection(String address, DataStore store);
    int reportFault(String issue, String area, DataStore store);
    String checkComplaintStatus(int complaintId, DataStore store);
    List<PowerSchedule> viewPowerSchedule(String area, DataStore store);
    List<Bill> viewBill(int userId, DataStore store);
    void payBill(int billId, DataStore store);
    void giveFeedback(String message, int rating, DataStore store);
}

/* ======================= Concrete User Classes =========================== */
class Admin extends AbstractUser implements Authenticator, AdminOps {

    private final String password;
    private static final String ADMIN_ID = "moiz";
    private static final String ADMIN_PWD = "12345";
    private static final double TAX_RATE = 0.17;

    public Admin(String name, String password) {
        super(name);
        this.password = password;
    }

    @Override
    public void login(DataStore store) throws AuthenticationException {
        if (!ADMIN_ID.equalsIgnoreCase(name) || !ADMIN_PWD.equals(password)) {
            throw new AuthenticationException("Invalid admin credentials!");
        }
        System.out.println("Admin logged in successfully.");
    }

    /* AdminOps implementation */
    @Override
    public double calculateBill(int unitsUsed) {
        double rate = unitsUsed <= 100 ? 10 : unitsUsed <= 200 ? 12 : unitsUsed <= 300 ? 15 : 20;
        return unitsUsed * rate * (1 + TAX_RATE);
    }

    @Override
    public void generateMonthlyBill(int userId, DataStore store) {
        int totalUnits = store.getUnitsForUser(userId);
        double amount = calculateBill(totalUnits);
        Bill bill = new Bill(store.nextBillId(), userId, amount, LocalDate.now().plusDays(15));
        store.saveBill(bill);
        System.out.println("Monthly bill generated: " + bill);
    }

    @Override
    public void addLateFee(int billId, DataStore store) {
        Bill b = store.findBill(billId);
        if (b == null) {
            System.out.println("Bill not found.");
            return;
        }
        if (LocalDate.now().isAfter(b.getDueDate())) {
            b.setAmount(b.getAmount() * 1.10);
            store.updateBill(b);
            System.out.println("Late fee added.");
        } else {
            System.out.println("Due date not passed yet.");
        }
    }

    @Override
    public List<Bill> viewAllBills(DataStore store) {
        return store.allBills();
    }

    @Override
    public void createPowerSchedule(String area, LocalDate date, DataStore store) {
        store.saveSchedule(new PowerSchedule(area, date));
        System.out.println("Power schedule created for area: " + area + " on " + date);
    }

    @Override
    public void assignTechnician(int faultId, int techId, DataStore store) {
        FaultReport fr = store.findFault(faultId);
        if (fr != null) {
            fr.setTechnicianId(techId);
            fr.setStatus("Assigned");
            store.updateFault(fr);
            System.out.println("Technician " + techId + " assigned to fault " + faultId);
        } else {
            System.out.println("Fault not found.");
        }
    }

    @Override
    public List<FaultReport> viewFaultReports(DataStore store) {
        return store.allFaults();
    }

    @Override
    public void resolveFault(int faultId, DataStore store) {
        FaultReport fr = store.findFault(faultId);
        if (fr != null) {
            fr.setStatus("Resolved");
            store.updateFault(fr);
            System.out.println("Fault " + faultId + " resolved.");
        } else {
            System.out.println("Fault not found.");
        }
    }

    @Override
    public void addConnectionRequest(int userId, DataStore store) {
        ConnectionRequest request = new ConnectionRequest(store.nextConnectionRequestId(), userId, "Pending");
        store.saveConnectionRequest(request);
        System.out.println("Connection request added for user " + userId);
    }

    @Override
    public void approveConnection(int requestId, DataStore store) {
        ConnectionRequest request = store.findConnectionRequest(requestId);
        if (request != null) {
            request.setStatus("Approved");
            store.updateConnectionRequest(request);
            System.out.println("Connection request " + requestId + " approved.");
        } else {
            System.out.println("Connection request not found.");
        }
    }
}

class Citizen extends AbstractUser implements CitizenOps {

    public Citizen(String name) {
        super(name);
    }

    @Override
    public void register(DataStore store) throws DataAccessException {
        try {
            store.saveCitizen(this);
            System.out.println("Citizen registered successfully: " + this.name);
        } catch (Exception e) {
            throw new DataAccessException("Failed to register citizen: " + e.getMessage());
        }
    }

    @Override
    public void requestNewConnection(String address, DataStore store) {
        ConnectionRequest request = new ConnectionRequest(store.nextConnectionRequestId(), this.id, "Pending");
        request.setAddress(address);
        store.saveConnectionRequest(request);
        System.out.println("New connection request submitted for address: " + address);
    }

    @Override
    public int reportFault(String issue, String area, DataStore store) {
        FaultReport fault = new FaultReport(store.nextFaultId(), issue, area);
        fault.setReportedBy(this.id);
        store.saveFaultReport(fault);
        return fault.getId();
    }

    @Override
    public String checkComplaintStatus(int complaintId, DataStore store) {
        FaultReport fault = store.findFault(complaintId);
        if (fault != null) {
            return "Complaint ID " + complaintId + " status: " + fault.getStatus();
        }
        return "Complaint not found.";
    }

    @Override
    public List<PowerSchedule> viewPowerSchedule(String area, DataStore store) {
        return store.getSchedulesByArea(area);
    }

    @Override
    public List<Bill> viewBill(int userId, DataStore store) {
        return store.getBillsByUserId(userId);
    }

    @Override
    public void payBill(int billId, DataStore store) {
        Bill bill = store.findBill(billId);
        if (bill != null) {
            bill.setStatus("Paid");
            store.updateBill(bill);
            System.out.println("Bill " + billId + " paid successfully.");
        } else {
            System.out.println("Bill not found.");
        }
    }

    @Override
    public void giveFeedback(String message, int rating, DataStore store) {
        if (rating < 1 || rating > 5) {
            System.out.println("Rating must be between 1-5.");
            return;
        }
        Feedback feedback = new Feedback(store.nextFeedbackId(), this.id, message, rating);
        store.saveFeedback(feedback);
        System.out.println("Feedback submitted successfully.");
    }
}

/* ======================= Data Model Classes =========================== */

class Bill {
    private int id;
    private int userId;
    private double amount;
    private LocalDate dueDate;
    private String status = "Unpaid";

    public Bill(int id, int userId, double amount, LocalDate dueDate) {
        this.id = id;
        this.userId = userId;
        this.amount = amount;
        this.dueDate = dueDate;
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public LocalDate getDueDate() { return dueDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "Bill{id=" + id + ", userId=" + userId + ", amount=" + amount + 
               ", dueDate=" + dueDate + ", status='" + status + "'}";
    }
}

class FaultReport {
    private int id;
    private String issue;
    private String area;
    private int technicianId = -1;
    private String status = "Reported";
    private int reportedBy;

    public FaultReport(int id, String issue, String area) {
        this.id = id;
        this.issue = issue;
        this.area = area;
    }

    public int getId() { return id; }
    public String getIssue() { return issue; }
    public String getArea() { return area; }
    public int getTechnicianId() { return technicianId; }
    public void setTechnicianId(int technicianId) { this.technicianId = technicianId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getReportedBy() { return reportedBy; }
    public void setReportedBy(int reportedBy) { this.reportedBy = reportedBy; }

    @Override
    public String toString() {
        return "FaultReport{id=" + id + ", issue='" + issue + "', area='" + area + 
               "', technicianId=" + technicianId + ", status='" + status + "'}";
    }
}

class PowerSchedule {
    private String area;
    private LocalDate date;
    private String timeSlot = "08:00-18:00";

    public PowerSchedule(String area, LocalDate date) {
        this.area = area;
        this.date = date;
    }

    public String getArea() { return area; }
    public LocalDate getDate() { return date; }
    public String getTimeSlot() { return timeSlot; }
    public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }

    @Override
    public String toString() {
        return "PowerSchedule{area='" + area + "', date=" + date + ", timeSlot='" + timeSlot + "'}";
    }
}

class ConnectionRequest {
    private int id;
    private int userId;
    private String status;
    private String address;
    private LocalDate requestDate;

    public ConnectionRequest(int id, int userId, String status) {
        this.id = id;
        this.userId = userId;
        this.status = status;
        this.requestDate = LocalDate.now();
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public LocalDate getRequestDate() { return requestDate; }

    @Override
    public String toString() {
        return "ConnectionRequest{id=" + id + ", userId=" + userId + 
               ", status='" + status + "', address='" + address + "'}";
    }
}

class Feedback {
    private int id;
    private int userId;
    private String message;
    private int rating;
    private LocalDate date;

    public Feedback(int id, int userId, String message, int rating) {
        this.id = id;
        this.userId = userId;
        this.message = message;
        this.rating = rating;
        this.date = LocalDate.now();
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public String getMessage() { return message; }
    public int getRating() { return rating; }
    public LocalDate getDate() { return date; }

    @Override
    public String toString() {
        return "Feedback{id=" + id + ", userId=" + userId + ", message='" + message + 
               "', rating=" + rating + ", date=" + date + "}";
    }
}

/* ======================= Exception Classes =========================== */

class AuthenticationException extends Exception {
    public AuthenticationException(String message) {
        super(message);
    }
}

class DataAccessException extends Exception {
    public DataAccessException(String message) {
        super(message);
    }
}

/* ======================= DataStore Interface & Implementation ========= */

interface DataStore {
    // Bill operations
    int getUnitsForUser(int userId);
    void saveBill(Bill bill);
    Bill findBill(int billId);
    void updateBill(Bill bill);
    List<Bill> allBills();
    List<Bill> getBillsByUserId(int userId);
    int nextBillId();
    
    // Schedule operations
    void saveSchedule(PowerSchedule schedule);
    List<PowerSchedule> getSchedulesByArea(String area);
    
    // Fault operations
    FaultReport findFault(int faultId);
    void updateFault(FaultReport faultReport);
    List<FaultReport> allFaults();
    void saveFaultReport(FaultReport faultReport);
    int nextFaultId();
    
    // Connection request operations
    void saveConnectionRequest(ConnectionRequest request);
    ConnectionRequest findConnectionRequest(int requestId);
    void updateConnectionRequest(ConnectionRequest request);
    int nextConnectionRequestId();
    
    // Citizen operations
    void saveCitizen(Citizen citizen);
    
    // Feedback operations
    void saveFeedback(Feedback feedback);
    int nextFeedbackId();
}

/* Simple FileDataStore implementation */
class FileDataStore implements DataStore {
    private final List<Bill> bills = new ArrayList<>();
    private final List<FaultReport> faults = new ArrayList<>();
    private final List<PowerSchedule> schedules = new ArrayList<>();
    private final List<ConnectionRequest> connectionRequests = new ArrayList<>();
    private final List<Citizen> citizens = new ArrayList<>();
    private final List<Feedback> feedbacks = new ArrayList<>();
    
    private int billCounter = 1;
    private int faultCounter = 1;
    private int connectionRequestCounter = 1;
    private int feedbackCounter = 1;

    @Override
    public int getUnitsForUser(int userId) {
        // dummy implementation, returns random units between 50-300
        return 50 + (int)(Math.random() * 250);
    }

    @Override
    public void saveBill(Bill bill) {
        bills.add(bill);
    }

    @Override
    public Bill findBill(int billId) {
        return bills.stream().filter(b -> b.getId() == billId).findFirst().orElse(null);
    }

    @Override
    public void updateBill(Bill bill) {
        for (int i = 0; i < bills.size(); i++) {
            if (bills.get(i).getId() == bill.getId()) {
                bills.set(i, bill);
                return;
            }
        }
    }

    @Override
    public List<Bill> allBills() {
        return new ArrayList<>(bills);
    }

    @Override
    public List<Bill> getBillsByUserId(int userId) {
        return bills.stream().filter(b -> b.getUserId() == userId).toList();
    }

    @Override
    public int nextBillId() {
        return billCounter++;
    }

    @Override
    public void saveSchedule(PowerSchedule schedule) {
        schedules.add(schedule);
    }

    @Override
    public List<PowerSchedule> getSchedulesByArea(String area) {
        return schedules.stream().filter(s -> s.getArea().equalsIgnoreCase(area)).toList();
    }

    @Override
    public FaultReport findFault(int faultId) {
        return faults.stream().filter(f -> f.getId() == faultId).findFirst().orElse(null);
    }

    @Override
    public void updateFault(FaultReport faultReport) {
        for (int i = 0; i < faults.size(); i++) {
            if (faults.get(i).getId() == faultReport.getId()) {
                faults.set(i, faultReport);
                return;
            }
        }
    }

    @Override
    public List<FaultReport> allFaults() {
        return new ArrayList<>(faults);
    }

    @Override
    public void saveFaultReport(FaultReport faultReport) {
        faults.add(faultReport);
    }

    @Override
    public int nextFaultId() {
        return faultCounter++;
    }

    @Override
    public void saveConnectionRequest(ConnectionRequest request) {
        connectionRequests.add(request);
    }

    @Override
    public ConnectionRequest findConnectionRequest(int requestId) {
        return connectionRequests.stream().filter(r -> r.getId() == requestId).findFirst().orElse(null);
    }

    @Override
    public void updateConnectionRequest(ConnectionRequest request) {
        for (int i = 0; i < connectionRequests.size(); i++) {
            if (connectionRequests.get(i).getId() == request.getId()) {
                connectionRequests.set(i, request);
                return;
            }
        }
    }

    @Override
    public int nextConnectionRequestId() {
        return connectionRequestCounter++;
    }

    @Override
    public void saveCitizen(Citizen citizen) {
        citizens.add(citizen);
    }

    @Override
    public void saveFeedback(Feedback feedback) {
        feedbacks.add(feedback);
    }

    @Override
    public int nextFeedbackId() {
        return feedbackCounter++;
    }
}




