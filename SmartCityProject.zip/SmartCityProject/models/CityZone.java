package models;

import java.util.ArrayList;
import java.util.List;

public class CityZone {
    private String zoneName;
    private List<CityResource> resourceHub; // Aggregated resources

    public CityZone(String zoneName) {
        this.zoneName = zoneName;
        this.resourceHub = new ArrayList<>();
    }

    public String getZoneName() {
        return zoneName;
    }

    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    public List<CityResource> getResourceHub() {
        return resourceHub;
    }

    public void addResource(CityResource resource) {
        resourceHub.add(resource);
    }

    public void removeResource(String resourceID) {
        resourceHub.removeIf(r -> r.getResourceID().equalsIgnoreCase(resourceID));
    }

    public CityResource getResourceById(String resourceID) {
        for (CityResource resource : resourceHub) {
            if (resource.getResourceID().equalsIgnoreCase(resourceID)) {
                return resource;
            }
        }
        return null;
    }

    public void printAllResources() {
        System.out.println("Resources in Zone: " + zoneName);
        for (CityResource resource : resourceHub) {
            System.out.println(resource.toString());
        }
    }

    @Override
    public String toString() {
        return "CityZone{" +
                "zoneName='" + zoneName + '\'' +
                ", totalResources=" + resourceHub.size() +
                '}';
    }
}
