package models;

import java.io.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/*
  EmergencyServices.java
  A modern city emergency service management system focusing on Ambulance Service,
  demonstrating OOP concepts: inheritance, polymorphism, interfaces, composition,
  aggregation, abstract classes, file handling, and generics.
*/

/* ===================== Abstract Base Class (Person) ====================== */
abstract class Person {
    protected static int COUNTER = 1;
    protected final int id;
    protected String name;

    protected Person(String name) {
        this.id = COUNTER++;
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{id=" + id + ", name='" + name + "'}";
    }
}

/* =============== Interfaces for polymorphism and abstraction =============== */
interface Employee {
    void work();
}

interface EmergencyResponder {
    void respondToEmergency(EmergencyRequest request);
}

/* ================== Concrete Classes Demonstrating Inheritance ============== */
class Dispatcher extends Person implements Employee {
    private AmbulanceService ambulanceService;

    public Dispatcher(String name, AmbulanceService ambulanceService) {
        super(name);
        this.ambulanceService = ambulanceService; // Composition: Dispatcher has AmbulanceService
    }

    @Override
    public void work() {
        System.out.println(name + " is dispatching ambulances.");
    }

    public boolean dispatchAmbulance(EmergencyRequest request) {
        Ambulance ambulance = ambulanceService.getAvailableAmbulance();
        if (ambulance == null) {
            System.out.println("No available ambulances at the moment.");
            return false;
        }
        ambulance.respondToEmergency(request);
        ambulanceService.markAmbulanceBusy(ambulance.getId());
        return true;
    }
}

abstract class MedicalStaff extends Person implements Employee, EmergencyResponder {
    protected String specialization;

    public MedicalStaff(String name, String specialization) {
        super(name);
        this.specialization = specialization;
    }

    @Override
    public void work() {
        System.out.println(name + " (" + specialization + ") is on duty.");
    }

    @Override
    public abstract void respondToEmergency(EmergencyRequest request);
}

class Paramedic extends MedicalStaff {

    public Paramedic(String name) {
        super(name, "Paramedic");
    }

    @Override
    public void respondToEmergency(EmergencyRequest request) {
        System.out.println("Paramedic " + name + " responding to emergency at: " + request.getLocation());
    }
}

/* Ambulance class demonstrating aggregation */
class Ambulance implements EmergencyResponder, Serializable {
    private final int id;
    private String vehicleNumber;
    private boolean available;
    private List<MedicalStaff> staff; // Composition: Ambulance contains staff
    private static int AMB_COUNTER = 1;

    public Ambulance(String vehicleNumber) {
        this.id = AMB_COUNTER++;
        this.vehicleNumber = vehicleNumber;
        this.available = true;
        this.staff = new ArrayList<>();
    }

    public int getId() { return id; }
    public String getVehicleNumber() { return vehicleNumber; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    public void addStaff(MedicalStaff member) {
        staff.add(member);
    }

    public List<MedicalStaff> getStaff() { return staff; }

    @Override
    public void respondToEmergency(EmergencyRequest request) {
        System.out.println("Ambulance " + vehicleNumber + " dispatched to " + request.getLocation() + " with patient: " + request.getPatientName());
        for (MedicalStaff member : staff) {
            member.respondToEmergency(request);
        }
    }

    @Override
    public String toString() {
        return "Ambulance{id=" + id + ", vehicleNumber='" + vehicleNumber + "', available=" + available + ", staffCount=" + staff.size() + "}";
    }
}

/* Emergency request class with generics for flexibility */
class EmergencyRequest<T> implements Serializable {
    private static int REQUEST_COUNTER = 1;
    private final int requestId;
    private T patientInfo;
    private String location;
    private LocalDateTime requestTime;

    public EmergencyRequest(T patientInfo, String location) {
        this.requestId = REQUEST_COUNTER++;
        this.patientInfo = patientInfo;
        this.location = location;
        this.requestTime = LocalDateTime.now();
    }

    public int getRequestId() { return requestId; }
    public T getPatientInfo() { return patientInfo; }
    public String getPatientName() {
        if (patientInfo instanceof Patient) {
            return ((Patient) patientInfo).getName();
        } else {
            return patientInfo.toString();
        }
    }
    public String getLocation() { return location; }
    public LocalDateTime getRequestTime() { return requestTime; }

    @Override
    public String toString() {
        return "EmergencyRequest{id=" + requestId + ", patient=" + patientInfo + ", location='" + location + "', requestTime=" + requestTime + "}";
    }
}

/* Patient class */
class Patient {
    private String name;
    private int age;
    private String condition;

    public Patient(String name, int age, String condition) {
        this.name = name;
        this.age = age;
        this.condition = condition;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public String getCondition() { return condition; }

    @Override
    public String toString() {
        return "Patient{name='" + name + "', age=" + age + ", condition='" + condition + "'}";
    }
}

/* AmbulanceService manages ambulances and persistence */
class AmbulanceService {
    private Map<Integer, Ambulance> ambulances;
    private final String dataFile = "ambulances.dat";

    public AmbulanceService() {
        ambulances = new HashMap<>();
        loadAmbulances();
    }

    public void addAmbulance(Ambulance amb) {
        ambulances.put(amb.getId(), amb);
        saveAmbulances();
    }

    public Ambulance getAvailableAmbulance() {
        for (Ambulance amb : ambulances.values()) {
            if (amb.isAvailable()) return amb;
        }
        return null;
    }

    public void markAmbulanceBusy(int ambulanceId) {
        Ambulance amb = ambulances.get(ambulanceId);
        if (amb != null) {
            amb.setAvailable(false);
            saveAmbulances();
        }
    }

    public void markAmbulanceAvailable(int ambulanceId) {
        Ambulance amb = ambulances.get(ambulanceId);
        if (amb != null) {
            amb.setAvailable(true);
            saveAmbulances();
        }
    }

    public List<Ambulance> getAllAmbulances() {
        return new ArrayList<>(ambulances.values());
    }

    private void saveAmbulances() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(dataFile))) {
            oos.writeObject(ambulances);
        } catch (IOException e) {
            System.err.println("Error saving ambulance data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadAmbulances() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(dataFile))) {
            ambulances = (Map<Integer, Ambulance>) ois.readObject();
        } catch (FileNotFoundException e) {
            // First run, no data file
            ambulances = new HashMap<>();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading ambulance data: " + e.getMessage());
            ambulances = new HashMap<>();
        }
    }
}

/* Main application to demonstrate functionality */
public class EmergencyServiceApp {
    private static final Scanner SCANNER = new Scanner(System.in);
    private static AmbulanceService ambulanceService = new AmbulanceService();
    private static Dispatcher dispatcher;

    public static void main(String[] args) {
        System.out.println("=== Welcome to Modern City Emergency Ambulance Service ===");

        // Setup dispatcher and ambulances
        setupInitialData();

        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Add Ambulance");
            System.out.println("2. Add Medical Staff to Ambulance");
            System.out.println("3. View Ambulances");
            System.out.println("4. Dispatch Ambulance");
            System.out.println("5. Mark Ambulance Available");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");

            int option;
            try {
                option = Integer.parseInt(SCANNER.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, please enter a number.");
                continue;
            }

            switch (option) {
                case 1 -> addAmbulance();
                case 2 -> addStaffToAmbulance();
                case 3 -> viewAmbulances();
                case 4 -> dispatchAmbulance();
                case 5 -> markAmbulanceAvailable();
                case 0 -> {
                    System.out.println("Exiting Emergency Service App.");
                    System.exit(0);
                }
                default -> System.out.println("Invalid option selected.");
            }
        }
    }

    private static void setupInitialData() {
        ambulanceService = new AmbulanceService();
        dispatcher = new Dispatcher("Dispatcher1", ambulanceService);

        if (ambulanceService.getAllAmbulances().isEmpty()) {
            Ambulance amb1 = new Ambulance("MC-101");
            amb1.addStaff(new Paramedic("Alice"));
            ambulanceService.addAmbulance(amb1);

            Ambulance amb2 = new Ambulance("MC-102");
            amb2.addStaff(new Paramedic("Bob"));
            ambulanceService.addAmbulance(amb2);
        }
    }

    private static void addAmbulance() {
        System.out.print("Enter Ambulance vehicle number: ");
        String vehicleNumber = SCANNER.nextLine();
        Ambulance amb = new Ambulance(vehicleNumber);
        ambulanceService.addAmbulance(amb);
        System.out.println("Ambulance added: " + amb);
    }

    private static void addStaffToAmbulance() {
        System.out.print("Enter Ambulance ID: ");
        int ambId;
        try {
            ambId = Integer.parseInt(SCANNER.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ambulance ID.");
            return;
        }
        Ambulance amb = ambulanceService.getAllAmbulances().stream()
                .filter(a -> a.getId() == ambId).findFirst().orElse(null);

        if (amb == null) {
            System.out.println("Ambulance not found.");
            return;
        }

        System.out.print("Enter medical staff name: ");
        String name = SCANNER.nextLine();
        Paramedic paramedic = new Paramedic(name);
        amb.addStaff(paramedic);
        ambulanceService.markAmbulanceAvailable(ambId); // Refresh data file after change
        System.out.println("Paramedic added: " + paramedic.getName() + " to Ambulance ID " + ambId);
    }

    private static void viewAmbulances() {
        List<Ambulance> ambulances = ambulanceService.getAllAmbulances();
        if (ambulances.isEmpty()) {
            System.out.println("No ambulances in the system.");
            return;
        }
        ambulances.forEach(amb -> {
            System.out.println(amb);
            System.out.println(" Staff:");
            amb.getStaff().forEach(staff -> System.out.println("  - " + staff));
        });
    }

    private static void dispatchAmbulance() {
        System.out.print("Enter patient name: ");
        String name = SCANNER.nextLine();

        System.out.print("Enter patient age: ");
        int age;
        try {
            age = Integer.parseInt(SCANNER.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid age entered.");
            return;
        }

        System.out.print("Enter patient condition: ");
        String condition = SCANNER.nextLine();

        System.out.print("Enter emergency location: ");
        String location = SCANNER.nextLine();

        Patient patient = new Patient(name, age, condition);
        EmergencyRequest<Patient> request = new EmergencyRequest<>(patient, location);

        boolean dispatched = dispatcher.dispatchAmbulance(request);
        if (dispatched) {
            System.out.println("Ambulance dispatched successfully.");
        } else {
            System.out.println("Failed to dispatch ambulance.");
        }
    }

    private static void markAmbulanceAvailable() {
        System.out.print("Enter Ambulance ID to mark as available: ");
        int ambId;
        try {
            ambId = Integer.parseInt(SCANNER.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ambulance ID.");
            return;
        }
        ambulanceService.markAmbulanceAvailable(ambId);
        System.out.println("Ambulance " + ambId + " marked as available.");
    }
}

