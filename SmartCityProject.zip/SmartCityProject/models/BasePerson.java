package models;

public abstract class BasePerson {
    protected static int COUNTER = 1; // Static counter to assign unique IDs
    protected final int id; // Unique ID for each person
    protected String name; // Name of the person

    // Constructor to initialize the name and assign a unique ID
    protected BasePerson(String name) {
        this.id = COUNTER++;
        this.name = name;
    }

    // Getter for ID
    public int getId() { 
        return id; 
    }

    // Getter for name
    public String getName() { 
        return name; 
    }

    // Override toString method for better representation
    @Override
    public String toString() {
        return getClass().getSimpleName() + "{" + "id=" + id + ", name='" + name + '\'' + '}';
    }
}
