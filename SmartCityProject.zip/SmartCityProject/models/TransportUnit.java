package models;

import java.io.*;
import java.util.*;

public class TransportUnit {
    private static double farePerKM = 5.0;
    private static final String ROUTE_FILE = "routes.dat";
    private static final String FARE_FILE = "fare.dat";
    private static final String ADMIN_USER = "moiz";
    private static final String ADMIN_PASS = "12345";
    private static Map<String, Map<String, Double>> routes = new LinkedHashMap<>();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        loadData();
        boolean running = true;
        while (running) {
            System.out.println("\n=== Transport Service System ===");
            System.out.println("1. Login as Admin");
            System.out.println("2. Continue as Citizen");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                System.out.print("Enter admin username: ");
                String user = scanner.nextLine();
                System.out.print("Enter password: ");
                String pass = scanner.nextLine();

                if (user.equals(ADMIN_USER) && pass.equals(ADMIN_PASS)) {
                    adminMenu();
                } else {
                    System.out.println("❌ Invalid credentials. Access denied.");
                }
            } else if (choice == 2) {
                askForRoute();
            } else {
                System.out.println("❌ Invalid choice.");
            }

            System.out.print("\nDo you want to go again? (yes/no): ");
            String again = scanner.nextLine();
            if (!again.equalsIgnoreCase("yes")) {
                running = false;
                System.out.println("Thank you for using Transport Service.");
            }
        }
    }

    private static void adminMenu() {
        boolean active = true;
        while (active) {
            System.out.println("\n--- Admin Panel ---");
            System.out.println("1. Update Fare/km");
            System.out.println("2. Add Start Point");
            System.out.println("3. Add Destination to Start Point");
            System.out.println("4. View Routes");
            System.out.println("5. Exit Admin Panel");
            System.out.print("Choice: ");
            int opt = scanner.nextInt();
            scanner.nextLine();

            switch (opt) {
                case 1 -> {
                    System.out.print("Enter new fare/km: ");
                    farePerKM = scanner.nextDouble();
                    scanner.nextLine();
                    saveFare();
                    System.out.println("✔️ Fare updated to Rs " + farePerKM + "/km.");
                }
                case 2 -> {
                    System.out.print("Enter new start point: ");
                    String start = scanner.nextLine();
                    routes.putIfAbsent(start, new LinkedHashMap<>());
                    saveRoutes();
                    System.out.println("✔️ Start point added.");
                }
                case 3 -> {
                    System.out.print("Enter start point: ");
                    String from = scanner.nextLine();
                    if (!routes.containsKey(from)) {
                        System.out.println("⚠️ Start point not found.");
                        break;
                    }
                    System.out.print("Enter destination: ");
                    String to = scanner.nextLine();
                    System.out.print("Enter distance in km: ");
                    double dist = scanner.nextDouble();
                    scanner.nextLine();
                    routes.get(from).put(to, dist);
                    saveRoutes();
                    System.out.println("✔️ Destination added.");
                }
                case 4 -> {
                    System.out.println("--- Current Routes ---");
                    for (String start : routes.keySet()) {
                        System.out.println("From " + start);
                        for (var entry : routes.get(start).entrySet()) {
                            System.out.println(" → " + entry.getKey() + " : " + entry.getValue() + " km");
                        }
                    }
                }
                case 5 -> active = false;
                default -> System.out.println("❌ Invalid option.");
            }
        }
    }

    private static void askForRoute() {
        if (routes.isEmpty()) {
            System.out.println("No routes available.");
            return;
        }

        List<String> keys = new ArrayList<>(routes.keySet());
        for (int i = 0; i < keys.size(); i++) {
            System.out.println((i + 1) + ". " + keys.get(i));
        }

        System.out.print("Choose start point: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        String start = keys.get(choice - 1);
        Map<String, Double> destinations = routes.get(start);

        List<String> destKeys = new ArrayList<>(destinations.keySet());
        for (int i = 0; i < destKeys.size(); i++) {
            System.out.println((i + 1) + ". " + destKeys.get(i) + " - " + destinations.get(destKeys.get(i)) + " km");
        }

        System.out.print("Choose destination: ");
        int destChoice = scanner.nextInt();
        scanner.nextLine();

        String dest = destKeys.get(destChoice - 1);
        double dist = destinations.get(dest);
        double fare = dist * farePerKM;

        System.out.println("\n--- Route Summary ---");
        System.out.println("From: " + start);
        System.out.println("To: " + dest);
        System.out.println("Distance: " + dist + " km");
        System.out.println("Fare: Rs " + fare);
    }

    private static void saveRoutes() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ROUTE_FILE))) {
            oos.writeObject(routes);
        } catch (IOException e) {
            System.out.println("❌ Error saving routes: " + e.getMessage());
        }
    }

    private static void saveFare() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FARE_FILE))) {
            writer.write(String.valueOf(farePerKM));
        } catch (IOException e) {
            System.out.println("❌ Error saving fare: " + e.getMessage());
        }
    }

    private static void loadData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ROUTE_FILE))) {
            routes = (Map<String, Map<String, Double>>) ois.readObject();
        } catch (Exception e) {
            routes = new LinkedHashMap<>();
            routes.put("COMSATS University", new LinkedHashMap<>(Map.of("I-8 Markaz", 14.0, "F-6", 16.2)));
            routes.put("Faizabad", new LinkedHashMap<>(Map.of("PIMS", 6.8, "F-6", 10.0)));
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(FARE_FILE))) {
            farePerKM = Double.parseDouble(reader.readLine());
        } catch (Exception e) {
            farePerKM = 5.0;
        }
    }
}
