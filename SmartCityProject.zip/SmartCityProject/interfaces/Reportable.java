package interfaces;

public interface Reportable {
    String generateUsageReport();
}
