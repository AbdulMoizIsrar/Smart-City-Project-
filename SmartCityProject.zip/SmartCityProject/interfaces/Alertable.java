package interfaces;

public interface Alertable {
    void sendEmergencyAlert();
}
